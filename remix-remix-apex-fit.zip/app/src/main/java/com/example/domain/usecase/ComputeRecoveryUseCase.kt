package com.example.domain.usecase

import com.example.model.PsychState
import com.example.model.TensionZone
import com.example.model.ZoneStatus
import kotlin.math.roundToInt

class ComputeRecoveryUseCase {
    operator fun invoke(
        psych: PsychState,
        sleepHours: Float,
        hrvMs: Int,
        rhrBpm: Int,
        zones: Map<TensionZone, ZoneStatus>
    ): Int {
        val zAvg = if (zones.isEmpty()) 85f else zones.values.map { it.pct.toFloat() }.average().toFloat()
        val raw = 66f +
            (sleepHours - 6f) * 6f +
            (hrvMs - 55) * 0.35f +
            (55 - rhrBpm) * 0.4f +
            (zAvg - 85f) * 0.5f +
            psych.delta
        return raw.roundToInt().coerceIn(20, 99)
    }
}
