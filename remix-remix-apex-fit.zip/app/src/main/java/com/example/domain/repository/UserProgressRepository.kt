package com.example.domain.repository

import com.example.model.ApexUiState
import com.example.model.PsychState
import com.example.model.TensionZone
import com.example.model.ZoneStatus

interface UserProgressRepository {
    suspend fun loadInitialState(
        recalcFn: (PsychState, Float, Int, Int, Map<TensionZone, ZoneStatus>) -> Int
    ): ApexUiState

    suspend fun saveState(state: ApexUiState)
}
