package com.example.domain.repository

import com.example.model.FoodFact
import com.example.model.GearItem
import com.example.model.NutrientGuideItem
import com.example.model.Recipe

interface NutritionRepository {
    fun getRecipes(): List<Recipe>
    fun getRecipeAt(index: Int): Recipe?
    fun getFoodFacts(): List<FoodFact>
    fun getNutrientGuides(): List<NutrientGuideItem>
    fun getGearCatalog(): List<GearItem>
    fun getGearItemAt(index: Int): GearItem?
}
