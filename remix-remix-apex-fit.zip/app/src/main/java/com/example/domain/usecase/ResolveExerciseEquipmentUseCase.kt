package com.example.domain.usecase

import com.example.domain.repository.TrainingRepository
import com.example.model.Equipment
import com.example.model.Exercise
import com.example.model.ResolvedWorkoutExercise
import com.example.model.WorkoutPlan

class ResolveExerciseEquipmentUseCase(
    private val trainingRepository: TrainingRepository
) {
    fun resolveExercise(
        exerciseId: String,
        ownedEquipment: Set<Equipment>,
        swappedShoulderProtocol: Boolean
    ): Exercise {
        val exercises = trainingRepository.getExercises()
        val base = trainingRepository.getExerciseById(exerciseId) ?: exercises.first()
        val hasGear = base.requiredEquipment.all { it in ownedEquipment }
        var resolvedId = if (!hasGear && base.fallbackId != null) base.fallbackId else exerciseId
        if (swappedShoulderProtocol && resolvedId == "wall-hspu") {
            resolvedId = "deficit-pike"
        }
        return trainingRepository.getExerciseById(resolvedId) ?: base
    }

    fun resolveWorkoutExercises(
        workout: WorkoutPlan,
        ownedEquipment: Set<Equipment>,
        swappedShoulderProtocol: Boolean
    ): List<ResolvedWorkoutExercise> {
        return workout.exercises.map { spec ->
            ResolvedWorkoutExercise(
                exercise = resolveExercise(spec.exerciseId, ownedEquipment, swappedShoulderProtocol),
                sets = spec.sets,
                reps = spec.reps,
                tempoSec = spec.tempoSec,
                restSec = spec.restSec
            )
        }
    }
}
