package com.example.domain.usecase

import com.example.data.StringsData
import com.example.model.BiText
import com.example.model.ChatMessage

class CoachEngineUseCase {
    operator fun invoke(
        rawText: String,
        recoveryPercent: Int,
        timestampMillis: Long = System.currentTimeMillis()
    ): Pair<ChatMessage, ChatMessage>? {
        val text = rawText.trim()
        if (text.isEmpty()) return null
        val lower = text.lowercase()
        val userMsg = ChatMessage(
            id = "u_$timestampMillis",
            isUser = true,
            text = BiText(en = text, ar = text)
        )
        val replyMsg = when {
            Regex("shoulder|pinch|elbow|wrist|كتف|ألم|وخز|pain|hurt").containsMatchIn(lower) ->
                ChatMessage(id = "b_$timestampMillis", isUser = false, isSwapCard = true)
            Regex("squat|form|depth|knee|قرفصاء|وضعية|فورم|ركبة").containsMatchIn(lower) ->
                ChatMessage(id = "b_$timestampMillis", isUser = false, text = StringsData.coachForm)
            Regex("recover|sleep|tired|rest|استشفاء|نوم|تعب").containsMatchIn(lower) ->
                ChatMessage(id = "b_$timestampMillis", isUser = false, text = StringsData.coachRecovery(recoveryPercent))
            Regex("protein|food|eat|meal|nutrition|diet|بروتين|أكل|وجبة|تغذية").containsMatchIn(lower) ->
                ChatMessage(id = "b_$timestampMillis", isUser = false, text = StringsData.coachProtein)
            else ->
                ChatMessage(id = "b_$timestampMillis", isUser = false, text = StringsData.coachDefault)
        }
        return userMsg to replyMsg
    }
}
