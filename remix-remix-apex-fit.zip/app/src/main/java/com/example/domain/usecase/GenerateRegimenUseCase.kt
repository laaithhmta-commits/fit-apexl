package com.example.domain.usecase

import com.example.data.StringsData
import com.example.domain.repository.TrainingRepository
import com.example.model.AppLanguage
import com.example.model.BiText
import com.example.model.Equipment
import com.example.model.PsychState
import com.example.model.RegimenLevel
import com.example.model.UserRegimen

class GenerateRegimenUseCase(
    private val trainingRepository: TrainingRepository
) {
    operator fun invoke(
        recoveryPercent: Int,
        psych: PsychState,
        ownedEquipment: Set<Equipment>
    ): UserRegimen {
        val level = when {
            recoveryPercent < 60 || psych == PsychState.DRAINED || psych == PsychState.FATIGUED ->
                RegimenLevel.DELOAD
            recoveryPercent >= 85 && (psych == PsychState.FOCUSED || psych == PsychState.PEAK) ->
                RegimenLevel.BUILD
            else -> RegimenLevel.MAINTAIN
        }
        val workoutId = when (level) {
            RegimenLevel.DELOAD -> "mob1"
            RegimenLevel.BUILD -> "planche"
            RegimenLevel.MAINTAIN -> "hs"
        }
        return buildNote(level, workoutId, recoveryPercent, psych, ownedEquipment)
    }

    fun buildNote(
        level: RegimenLevel,
        workoutId: String,
        recoveryPercent: Int,
        psych: PsychState,
        ownedEquipment: Set<Equipment>
    ): UserRegimen {
        val workouts = trainingRepository.getWorkouts()
        val wo = trainingRepository.getWorkoutById(workoutId) ?: workouts.first()
        val eqEn = if (ownedEquipment.isEmpty()) {
            StringsData.equipmentName(Equipment.NONE, AppLanguage.EN)
        } else {
            ownedEquipment.joinToString(", ") { StringsData.equipmentName(it, AppLanguage.EN) }
        }
        val eqAr = if (ownedEquipment.isEmpty()) {
            StringsData.equipmentName(Equipment.NONE, AppLanguage.AR)
        } else {
            ownedEquipment.joinToString("، ") { StringsData.equipmentName(it, AppLanguage.AR) }
        }

        val enNote = "${level.key} day · ${wo.title.en}. Recovery $recoveryPercent% · ${StringsData.psychName(psych, AppLanguage.EN)}. Equipment: $eqEn."
        val arNote = "يوم ${StringsData.regimenLevelName(level, AppLanguage.AR)} · ${wo.title.ar}. الاستشفاء $recoveryPercent% · ${StringsData.psychName(psych, AppLanguage.AR)}. المعدات: $eqAr."
        return UserRegimen(level, wo.id, BiText(en = enNote, ar = arNote))
    }
}
