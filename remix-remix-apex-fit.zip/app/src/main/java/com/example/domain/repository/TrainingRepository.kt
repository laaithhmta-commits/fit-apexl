package com.example.domain.repository

import com.example.data.MuscleAnchor
import com.example.data.PoseFrame
import com.example.model.Exercise
import com.example.model.PoseType
import com.example.model.TrainingProgram
import com.example.model.WorkoutPlan

interface TrainingRepository {
    fun getPrograms(): List<TrainingProgram>
    fun getWorkouts(): List<WorkoutPlan>
    fun getWorkoutById(id: String): WorkoutPlan?
    fun getExercises(): List<Exercise>
    fun getExerciseById(id: String): Exercise?
    fun getPoseFrames(pose: PoseType): List<PoseFrame>
    fun getMuscleAnchors(pose: PoseType): List<MuscleAnchor>
}
