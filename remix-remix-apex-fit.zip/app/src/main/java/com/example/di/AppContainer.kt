package com.example.di

import android.app.Application
import com.example.core.AndroidKineticFeedbackManager
import com.example.core.DefaultDispatcherProvider
import com.example.core.DispatcherProvider
import com.example.core.KineticFeedbackManager
import com.example.data.PreferencesRepository
import com.example.data.repository.DefaultNutritionRepository
import com.example.data.repository.DefaultTrainingRepository
import com.example.domain.repository.NutritionRepository
import com.example.domain.repository.TrainingRepository
import com.example.domain.repository.UserProgressRepository
import com.example.domain.usecase.CoachEngineUseCase
import com.example.domain.usecase.ComputeRecoveryUseCase
import com.example.domain.usecase.GenerateRegimenUseCase
import com.example.domain.usecase.ResolveExerciseEquipmentUseCase

interface AppContainer {
    val dispatchers: DispatcherProvider
    val trainingRepository: TrainingRepository
    val nutritionRepository: NutritionRepository
    val userProgressRepository: UserProgressRepository
    val feedbackManager: KineticFeedbackManager
    val computeRecoveryUseCase: ComputeRecoveryUseCase
    val generateRegimenUseCase: GenerateRegimenUseCase
    val resolveExerciseUseCase: ResolveExerciseEquipmentUseCase
    val coachEngineUseCase: CoachEngineUseCase
}

class DefaultAppContainer(application: Application) : AppContainer {
    override val dispatchers: DispatcherProvider by lazy { DefaultDispatcherProvider() }
    override val trainingRepository: TrainingRepository by lazy { DefaultTrainingRepository() }
    override val nutritionRepository: NutritionRepository by lazy { DefaultNutritionRepository() }
    override val userProgressRepository: UserProgressRepository by lazy { PreferencesRepository(application) }
    override val feedbackManager: KineticFeedbackManager by lazy { AndroidKineticFeedbackManager(application) }

    override val computeRecoveryUseCase: ComputeRecoveryUseCase by lazy { ComputeRecoveryUseCase() }
    override val generateRegimenUseCase: GenerateRegimenUseCase by lazy { GenerateRegimenUseCase(trainingRepository) }
    override val resolveExerciseUseCase: ResolveExerciseEquipmentUseCase by lazy {
        ResolveExerciseEquipmentUseCase(trainingRepository)
    }
    override val coachEngineUseCase: CoachEngineUseCase by lazy { CoachEngineUseCase() }
}
