package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExerciseData
import com.example.data.StringsData
import com.example.model.ApexUiState
import com.example.model.Exercise
import com.example.model.ExerciseCategory
import com.example.model.WorkoutPlan
import com.example.ui.components.AnimatedNeonBar
import com.example.ui.components.CautionBanner
import com.example.ui.components.Eyebrow
import com.example.ui.components.GlassCard
import com.example.ui.components.KineticFigureCanvas
import com.example.ui.components.NeonCtaButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HeartRed
import com.example.ui.theme.NeonLime
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun WorkoutsScreen(
    state: ApexUiState,
    heroWorkout: WorkoutPlan,
    heroLeadExercise: Exercise,
    onToggleStreakDay: (Int) -> Unit,
    onOpenWorkout: (String) -> Unit,
    onOpenExercise: (String) -> Unit,
    onSelectProgramFilter: (String?) -> Unit,
    onSelectExerciseCategory: (ExerciseCategory?) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = state.language
    val programsShown = remember(state.programFilter) {
        ExerciseData.programs.filter { state.programFilter == null || it.id == state.programFilter }
    }
    val filteredExercises = remember(state.exerciseCategoryFilter, state.exerciseQuery) {
        val q = state.exerciseQuery.trim().lowercase()
        ExerciseData.exercises.filter { ex ->
            val catOk = state.exerciseCategoryFilter == null || ex.category == state.exerciseCategoryFilter
            val qOk = q.isEmpty() ||
                ex.name.en.lowercase().contains(q) ||
                ex.name.ar.lowercase().contains(q) ||
                ex.primaryMuscles.any { it.contains(q) }
            catOk && qOk
        }
    }

    val heartTransition = rememberInfiniteTransition(label = "heart")
    val heartScale by heartTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.24f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heartScale"
    )

    val heroProgram = ExerciseData.programs.find { it.id == heroWorkout.programId }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SectionHeader(
                    eyebrow = StringsData.kineticEyebrow.get(lang),
                    title = StringsData.engineTitle.get(lang),
                    badge = StringsData.lvlBadge.get(lang)
                )
            }

            // Streak Card
            item {
                GlassCard {
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = state.streakDays.count { it }.toString(),
                            style = MaterialTheme.typography.displaySmall.copy(fontSize = 40.sp),
                            color = NeonLime
                        )
                        Text(
                            text = StringsData.streak.get(lang),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextDim,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    val dayLabels = StringsData.weekDays(lang)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        dayLabels.forEachIndexed { idx, label ->
                            val done = state.streakDays.getOrElse(idx) { false }
                            val isToday = idx == 4
                            val borderColor = when {
                                isToday -> ElectricCyan
                                done -> NeonLime.copy(alpha = 0.6f)
                                else -> GlassBorder
                            }
                            val bg = when {
                                done -> NeonLime.copy(alpha = 0.12f)
                                else -> Color.Transparent
                            }
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(CircleShape)
                                    .background(bg)
                                    .border(1.dp, borderColor, CircleShape)
                                    .clickable { onToggleStreakDay(idx) }
                                    .testTag("streak_day_$idx")
                            ) {
                                if (done) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = label,
                                        tint = if (isToday) ElectricCyan else NeonLime,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (isToday) ElectricCyan else TextDim
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = StringsData.bioSynced.get(lang),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextDim
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "♥",
                                color = HeartRed,
                                fontSize = 15.sp,
                                modifier = Modifier.scale(heartScale)
                            )
                            Text(
                                text = "145 ${StringsData.bpm.get(lang)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // Daily Directive Card
            item {
                GlassCard {
                    Eyebrow(text = StringsData.directiveTitle.get(lang), color = ElectricCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = StringsData.directive.get(lang),
                        style = MaterialTheme.typography.bodyLarge,
                        fontStyle = FontStyle.Italic,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = StringsData.coachName.get(lang),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextDim
                    )
                }
            }

            // Persistent Session Telemetry Log Card
            item {
                val totalKcal = remember(state.workoutHistory) { state.workoutHistory.sumOf { it.kcal } }
                val totalSets = remember(state.workoutHistory) { state.workoutHistory.sumOf { it.setsCompleted } }
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Eyebrow(text = StringsData.sessionHistoryTitle.get(lang), color = NeonLime)
                        Surface(
                            shape = CircleShape,
                            color = NeonLime.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.45f))
                        ) {
                            Text(
                                text = "${state.workoutHistory.size} ${StringsData.sessionsCompleted.get(lang)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonLime,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    if (state.workoutHistory.isEmpty()) {
                        Text(
                            text = StringsData.noSessionsYet.get(lang),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextDim
                        )
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.03f),
                                border = BorderStroke(1.dp, GlassBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = StringsData.totalBurned.get(lang),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextDim
                                    )
                                    Text(
                                        text = "$totalKcal ${StringsData.kcal.get(lang)}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = NeonLime
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.03f),
                                border = BorderStroke(1.dp, GlassBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = StringsData.totalSets.get(lang),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextDim
                                    )
                                    Text(
                                        text = "$totalSets ${StringsData.sets.get(lang)}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = ElectricCyan
                                    )
                                }
                            }
                        }
                        state.workoutHistory.take(3).forEach { entry ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = entry.title.get(lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${entry.setsCompleted}× · ${entry.kcal} ${StringsData.kcal.get(lang)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricCyan
                                )
                            }
                        }
                    }
                }
            }

            // Optional Calibrated Regimen Banner
            if (state.regimen != null) {
                item {
                    GlassCard(neonBorder = ElectricCyan) {
                        Eyebrow(
                            text = "${StringsData.regimenTitle.get(lang)} · ${StringsData.regimenLevelName(state.regimen.level, lang)}",
                            color = ElectricCyan
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = state.regimen.note.get(lang),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Priority Protocol Hero Card
            item {
                GlassCard(neonBorder = NeonLime) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Eyebrow(
                            text = "${StringsData.priority.get(lang)} · ${heroProgram?.name?.get(lang).orEmpty()}",
                            color = NeonLime
                        )
                        Text(
                            text = "${heroWorkout.durationMin} ${StringsData.min.get(lang)} · ${heroWorkout.kcal} ${StringsData.kcal.get(lang)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextDim
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    KineticFigureCanvas(
                        pose = heroLeadExercise.pose,
                        language = lang,
                        tempoSec = 2f,
                        targetReps = 15,
                        muscleActivation = heroWorkout.muscles,
                        formCue = heroWorkout.cue.get(lang),
                        tagPrefix = "hero_fig"
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    heroWorkout.muscles.forEach { (muscleKey, pct) ->
                        AnimatedNeonBar(
                            label = StringsData.muscleName(muscleKey, lang),
                            percent = pct,
                            accent = if (pct >= 88) NeonLime else ElectricCyan
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = heroWorkout.title.get(lang),
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    CautionBanner(
                        title = StringsData.formCaution.get(lang),
                        message = heroWorkout.cue.get(lang)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    NeonCtaButton(
                        text = StringsData.startWorkout.get(lang),
                        onClick = { onOpenWorkout(heroWorkout.id) },
                        testTag = "start_hero_workout_button"
                    )
                }
            }

            // Elite Training Programs
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = StringsData.programs.get(lang),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChipPill(
                        label = StringsData.all.get(lang),
                        selected = state.programFilter == null,
                        onClick = { onSelectProgramFilter(null) },
                        testTag = "prog_filter_all"
                    )
                    ExerciseData.programs.forEach { prog ->
                        FilterChipPill(
                            label = prog.name.get(lang),
                            selected = state.programFilter == prog.id,
                            onClick = { onSelectProgramFilter(prog.id) },
                            testTag = "prog_filter_${prog.id}"
                        )
                    }
                }
            }

            items(programsShown, key = { it.id }) { prog ->
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Eyebrow(text = prog.name.get(lang), color = ElectricCyan)
                        Surface(
                            shape = CircleShape,
                            color = ElectricCyan.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "${prog.workoutIds.size} ${StringsData.plans.get(lang)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    prog.workoutIds.forEach { wid ->
                        val wo = ExerciseData.workoutsById[wid] ?: return@forEach
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.White.copy(alpha = 0.03f),
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                                .clickable { onOpenWorkout(wo.id) }
                                .testTag("workout_card_${wo.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = wo.title.get(lang),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = "${StringsData.workoutLevelName(wo.level, lang)} · ${wo.exercises.size} ${StringsData.exCount.get(lang)} · ${wo.durationMin} ${StringsData.min.get(lang)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextDim
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = wo.title.get(lang),
                                    tint = NeonLime,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Home Exercise Library · Men
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = StringsData.libraryTitle.get(lang),
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = StringsData.libraryNote.get(lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextDim
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = state.exerciseQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text(StringsData.searchEx.get(lang), color = TextDim) },
                    leadingIcon = {
                        Icon(Icons.Rounded.Search, contentDescription = null, tint = ElectricCyan)
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White.copy(alpha = 0.05f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f),
                        focusedBorderColor = ElectricCyan.copy(alpha = 0.6f),
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exercise_search_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChipPill(
                        label = StringsData.all.get(lang),
                        selected = state.exerciseCategoryFilter == null,
                        onClick = { onSelectExerciseCategory(null) },
                        testTag = "ex_cat_all"
                    )
                    ExerciseCategory.entries.forEach { cat ->
                        FilterChipPill(
                            label = StringsData.categoryName(cat, lang),
                            selected = state.exerciseCategoryFilter == cat,
                            onClick = { onSelectExerciseCategory(cat) },
                            testTag = "ex_cat_${cat.id}"
                        )
                    }
                }
            }

            if (filteredExercises.isEmpty()) {
                item {
                    Text(
                        text = StringsData.noFacts.get(lang),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextDim,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                items(filteredExercises, key = { it.id }) { ex ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.03f),
                        border = BorderStroke(1.dp, GlassBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenExercise(ex.id) }
                            .testTag("exercise_row_${ex.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ex.name.get(lang),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "${StringsData.categoryName(ex.category, lang)} · ${ex.primaryMuscles.joinToString(" · ") { StringsData.muscleName(it, lang) }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextDim
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = ex.name.get(lang),
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = StringsData.tip.get(lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun FilterChipPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = CircleShape,
        color = if (selected) NeonLime.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.03f),
        border = BorderStroke(1.dp, if (selected) NeonLime.copy(alpha = 0.55f) else GlassBorder),
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = if (selected) NeonLime else TextDim,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
        )
    }
}
