package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExerciseData
import com.example.data.StringsData
import com.example.model.ActiveSessionState
import com.example.model.AppLanguage
import com.example.model.Exercise
import com.example.model.ResolvedWorkoutExercise
import com.example.model.SessionPhase
import com.example.model.WorkoutPlan
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassElevated
import com.example.ui.theme.GlassSheetBg
import com.example.ui.theme.NeonLime
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutDetailBottomSheet(
    workout: WorkoutPlan,
    resolvedExercises: List<ResolvedWorkoutExercise>,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onOpenExerciseGuide: (String) -> Unit,
    onStartSession: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val programName = ExerciseData.programs.find { it.id == workout.programId }?.name?.get(language).orEmpty()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = GlassSheetBg,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .navigationBarsPadding()
        ) {
            Eyebrow(
                text = "$programName · ${StringsData.workoutLevelName(workout.level, language)}",
                color = ElectricCyan
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = workout.title.get(language),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${workout.durationMin} ${StringsData.min.get(language)}", style = MaterialTheme.typography.bodySmall, color = TextDim)
                Text("${workout.kcal} ${StringsData.kcal.get(language)}", style = MaterialTheme.typography.bodySmall, color = TextDim)
                Text("${workout.exercises.size} ${StringsData.exCount.get(language)}", style = MaterialTheme.typography.bodySmall, color = TextDim)
            }
            Spacer(modifier = Modifier.height(10.dp))
            CautionBanner(
                title = StringsData.formCaution.get(language),
                message = workout.cue.get(language)
            )
            Spacer(modifier = Modifier.height(14.dp))

            resolvedExercises.forEachIndexed { idx, item ->
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = GlassElevated,
                    border = BorderStroke(1.dp, NeonLime.copy(alpha = 0.2f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${idx + 1}. ${item.exercise.name.get(language)}",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${item.sets}×${item.reps}",
                                style = MaterialTheme.typography.labelMedium,
                                color = NeonLime
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "${StringsData.tempo.get(language)} ${item.tempoSec}${StringsData.halfRep.get(language)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextDim
                            )
                            Text(
                                text = "${StringsData.rest.get(language)} ${item.restSec}s",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextDim
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        KineticFigureCanvas(
                            pose = item.exercise.pose,
                            language = language,
                            tempoSec = item.tempoSec,
                            targetReps = item.reps,
                            muscleActivation = workout.muscles,
                            formCue = item.exercise.steps.get(language).getOrElse(1) { "" },
                            tagPrefix = "wo_${workout.id}_$idx"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = CircleShape,
                            color = Color.Transparent,
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier
                                .clickable { onOpenExerciseGuide(item.exercise.id) }
                                .testTag("wo_mistakes_${item.exercise.id}")
                        ) {
                            Text(
                                text = StringsData.mistakes.get(language),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextDim,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            NeonCtaButton(
                text = StringsData.startWorkout.get(language),
                onClick = { onStartSession(workout.id) },
                testTag = "begin_live_session_button"
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExerciseGuideBottomSheet(
    exercise: Exercise,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val muscleMap = buildMap {
        exercise.primaryMuscles.forEach { put(it, 92) }
        exercise.secondaryMuscles.forEach { put(it, 55) }
    }
    val steps = exercise.steps.get(language)
    val mistakes = exercise.mistakes.get(language)
    val levels = exercise.levels.get(language)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = GlassSheetBg,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .navigationBarsPadding()
        ) {
            Eyebrow(text = StringsData.categoryName(exercise.category, language), color = ElectricCyan)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = exercise.name.get(language),
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))
            KineticFigureCanvas(
                pose = exercise.pose,
                language = language,
                tempoSec = 2f,
                muscleActivation = muscleMap,
                autoPlay = true,
                tagPrefix = "guide_${exercise.id}"
            )

            Spacer(modifier = Modifier.height(12.dp))
            Eyebrow(text = StringsData.primary.get(language), color = NeonLime)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                exercise.primaryMuscles.forEach { m ->
                    MuscleChip(StringsData.muscleName(m, language), NeonLime)
                }
            }

            if (exercise.secondaryMuscles.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Eyebrow(text = StringsData.secondary.get(language), color = ElectricCyan)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    exercise.secondaryMuscles.forEach { m ->
                        MuscleChip(StringsData.muscleName(m, language), ElectricCyan)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            val stepLabels = listOf(
                StringsData.setup.get(language),
                StringsData.execution.get(language),
                StringsData.breathing.get(language)
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                steps.forEachIndexed { idx, txt ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.03f),
                        border = BorderStroke(1.dp, GlassBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = stepLabels.getOrElse(idx) { "${idx + 1}" }.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = txt, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(text = StringsData.mistakes.get(language), style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            mistakes.forEach { m ->
                Row(
                    modifier = Modifier.padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("!", color = AlertAmber, fontWeight = FontWeight.Bold)
                    Text(m, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(text = StringsData.progressions.get(language), style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))
            val lvlLabels = listOf(
                StringsData.beginner.get(language),
                StringsData.intermediate.get(language),
                StringsData.advanced.get(language)
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                levels.forEachIndexed { idx, lvl ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.03f),
                        border = BorderStroke(1.dp, GlassBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = lvlLabels.getOrElse(idx) { "" },
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonLime
                            )
                            Text(
                                text = lvl,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(26.dp))
        }
    }
}

@Composable
private fun MuscleChip(text: String, color: Color) {
    Surface(
        shape = CircleShape,
        color = Color.Transparent,
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun LiveSessionOverlay(
    session: ActiveSessionState,
    language: AppLanguage,
    onRepCompleted: (Int) -> Unit,
    onCompleteSet: () -> Unit,
    onSkipRest: () -> Unit,
    onTogglePause: () -> Unit,
    onEndSession: () -> Unit
) {
    BackHandler { onEndSession() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        if (session.phase == SessionPhase.COMPLETE) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 520.dp)
                    .padding(24.dp)
            ) {
                Eyebrow(text = StringsData.sessDone.get(language), color = NeonLime, pulsing = true)
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = StringsData.locked.get(language),
                    style = MaterialTheme.typography.displaySmall,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "${session.workout.title.get(language)} · ${session.workout.kcal} ${StringsData.kcal.get(language)} · ${session.sequence.size} ${StringsData.sessSets.get(language)}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextDim,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(28.dp))
                NeonCtaButton(
                    text = StringsData.finish.get(language),
                    onClick = onEndSession,
                    testTag = "session_finish_button"
                )
            }
        } else {
            val currentItem = session.sequence[session.currentIndex]
            val ex = currentItem.exercise
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                            .clickable(onClick = onEndSession)
                            .testTag("session_end_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = StringsData.endSession.get(language),
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Text(
                        text = session.workout.title.get(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricCyan,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                    )

                    Text(
                        text = "${session.currentIndex + 1}/${session.sequence.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = ex.exercise.name.get(language),
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "${StringsData.sets.get(language)} ${currentItem.setNumber} / ${ex.sets}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextDim
                    )
                    Text(
                        text = "${ex.reps} ${StringsData.reps.get(language)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextDim
                    )
                    Text(
                        text = "${StringsData.tempo.get(language)} ${ex.tempoSec}s",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextDim
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                KineticFigureCanvas(
                    pose = ex.exercise.pose,
                    language = language,
                    tempoSec = ex.tempoSec,
                    targetReps = ex.reps,
                    muscleActivation = session.workout.muscles,
                    formCue = ex.exercise.steps.get(language).getOrElse(1) { "" },
                    externalPlaying = session.isPlayingFigure,
                    resetKey = "${session.currentIndex}_${session.phase}",
                    tagPrefix = "sess_fig",
                    onRepCompleted = onRepCompleted
                )

                Spacer(modifier = Modifier.height(12.dp))
                CautionBanner(
                    title = StringsData.formCue.get(language),
                    message = ex.exercise.steps.get(language).firstOrNull().orEmpty()
                )

                Spacer(modifier = Modifier.height(18.dp))
                if (session.phase == SessionPhase.REST) {
                    Text(
                        text = StringsData.restLbl.get(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonLime
                    )
                    Text(
                        text = "${session.restSecondsLeft}s",
                        style = MaterialTheme.typography.displaySmall.copy(fontSize = 40.sp),
                        color = ElectricCyan
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    NeonCtaButton(
                        text = StringsData.skipRest.get(language),
                        onClick = onSkipRest,
                        testTag = "session_skip_rest_button"
                    )
                } else {
                    Text(
                        text = StringsData.work.get(language),
                        style = MaterialTheme.typography.headlineLarge,
                        color = ElectricCyan
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    NeonCtaButton(
                        text = StringsData.completeSet.get(language),
                        onClick = onCompleteSet,
                        testTag = "session_complete_set_button"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                NeonCtaButton(
                    text = if (session.isPaused) StringsData.resume.get(language) else StringsData.pauseSession.get(language),
                    onClick = onTogglePause,
                    outlined = true,
                    testTag = "session_pause_button"
                )
            }
        }
    }
}
