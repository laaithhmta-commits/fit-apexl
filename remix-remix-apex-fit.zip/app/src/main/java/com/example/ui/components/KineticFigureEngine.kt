package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExerciseData
import com.example.data.PoseFrame
import com.example.data.StringsData
import com.example.model.AppLanguage
import com.example.model.PoseType
import com.example.ui.theme.AlertAmber
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonLime
import com.example.ui.theme.ObsidianDeep
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt

private fun interpolateFrame(pose: PoseType, phase: Float): PoseFrame {
    val frames = ExerciseData.poseFrames[pose] ?: ExerciseData.poseFrames.getValue(PoseType.PUSHUP)
    val n = frames.size
    val idx = phase.toInt().mod(n)
    val frac = phase - phase.toInt()
    val eased = ((1f - cos(PI.toFloat() * frac)) / 2f)
    val a = frames[idx]
    val b = frames[(idx + 1) % n]
    fun lerpPt(p1: Pair<Float, Float>, p2: Pair<Float, Float>): Pair<Float, Float> =
        (p1.first + (p2.first - p1.first) * eased) to (p1.second + (p2.second - p1.second) * eased)
    return PoseFrame(
        h = lerpPt(a.h, b.h),
        s = lerpPt(a.s, b.s),
        e = lerpPt(a.e, b.e),
        w = lerpPt(a.w, b.w),
        hp = lerpPt(a.hp, b.hp),
        k = lerpPt(a.k, b.k),
        a = lerpPt(a.a, b.a)
    )
}

private fun jointAngleDeg(
    a: Pair<Float, Float>,
    b: Pair<Float, Float>,
    c: Pair<Float, Float>
): Int {
    val v1x = a.first - b.first
    val v1y = a.second - b.second
    val v2x = c.first - b.first
    val v2y = c.second - b.second
    val dot = v1x * v2x + v1y * v2y
    val mag = (hypot(v1x, v1y) * hypot(v2x, v2y)).coerceAtLeast(1f)
    val cosVal = (dot / mag).coerceIn(-1f, 1f)
    return (acos(cosVal) * 180f / PI.toFloat()).roundToInt()
}

@Composable
fun KineticFigureCanvas(
    pose: PoseType,
    language: AppLanguage,
    tempoSec: Float = 2f,
    targetReps: Int = 0,
    muscleActivation: Map<String, Int> = emptyMap(),
    formCue: String = "",
    autoPlay: Boolean = false,
    externalPlaying: Boolean? = null,
    resetKey: Any? = null,
    tagPrefix: String = "fig",
    onRepCompleted: ((Int) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var playing by remember(pose, resetKey) { mutableStateOf(autoPlay) }
    val effectivePlaying = externalPlaying ?: playing
    var phase by remember(pose, resetKey) { mutableFloatStateOf(0f) }
    var reps by remember(pose, resetKey) { mutableIntStateOf(0) }
    var showFormWarn by remember(pose, resetKey) { mutableStateOf(false) }

    LaunchedEffect(effectivePlaying, pose, tempoSec, targetReps, resetKey) {
        if (!effectivePlaying) return@LaunchedEffect
        var lastNanos = 0L
        val framesCount = (ExerciseData.poseFrames[pose]?.size ?: 2).toFloat()
        while (true) {
            withFrameNanos { nanos ->
                if (lastNanos != 0L) {
                    val dt = (nanos - lastNanos) / 1_000_000_000f
                    phase += dt / tempoSec.coerceAtLeast(0.5f)
                    if (phase >= framesCount) {
                        phase -= framesCount
                        reps += 1
                        if (formCue.isNotBlank() && reps % 4 == 0) {
                            showFormWarn = true
                        }
                        onRepCompleted?.invoke(reps)
                        if (targetReps > 0 && reps >= targetReps && externalPlaying == null) {
                            playing = false
                        }
                    }
                }
                lastNanos = nanos
            }
        }
    }

    LaunchedEffect(showFormWarn) {
        if (showFormWarn) {
            delay(1500L)
            showFormWarn = false
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "musclePulse")
    val muscleScale by pulseTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "muscleScale"
    )

    val textMeasurer = rememberTextMeasurer()
    val elbLabel = StringsData.elb.get(language)
    val kneLabel = StringsData.kne.get(language)
    val musFooter = StringsData.musAct.get(language)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0x0B00FFFF), ObsidianDeep.copy(alpha = 0.96f))
                )
            )
            .border(1.dp, NeonLime.copy(alpha = 0.20f), RoundedCornerShape(18.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${StringsData.liveSkeletal.get(language)} · ${pose.key.uppercase()}",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricCyan
            )
            Text(
                text = if (formCue.isNotBlank()) StringsData.formCheck.get(language) else StringsData.formOk.get(language),
                style = MaterialTheme.typography.labelSmall,
                color = NeonLime
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 310.dp)
                .aspectRatio(1f)
                .align(Alignment.CenterHorizontally)
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val scale = minOf(size.width, size.height) / 200f
                val offsetX = (size.width - 200f * scale) / 2f
                val offsetY = (size.height - 200f * scale) / 2f

                fun pt(p: Pair<Float, Float>): Offset =
                    Offset(offsetX + p.first * scale, offsetY + p.second * scale)

                val frame = interpolateFrame(pose, phase)

                // Ground grid reference line
                drawLine(
                    color = ElectricCyan.copy(alpha = 0.34f),
                    start = Offset(offsetX + 6f * scale, offsetY + 182f * scale),
                    end = Offset(offsetX + 194f * scale, offsetY + 182f * scale),
                    strokeWidth = 1.3f * scale,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f * scale, 4f * scale))
                )

                val limbColor = Color(0xFFE6EEF4)
                fun drawLimb(a: Pair<Float, Float>, b: Pair<Float, Float>, width: Float, alpha: Float) {
                    drawLine(
                        color = limbColor.copy(alpha = alpha),
                        start = pt(a),
                        end = pt(b),
                        strokeWidth = width * scale,
                        cap = StrokeCap.Round
                    )
                }

                drawLimb(frame.hp, frame.a, 6.5f, 0.48f)
                drawLimb(frame.hp, frame.k, 8.5f, 0.62f)
                drawLimb(frame.k, frame.a, 7.5f, 0.62f)
                drawLimb(frame.s, frame.hp, 11f, 0.46f)
                drawLimb(frame.s, frame.e, 6.5f, 0.68f)
                drawLimb(frame.e, frame.w, 5.5f, 0.68f)
                drawLimb(frame.h, frame.s, 3.8f, 0.58f)

                // Head circle
                drawCircle(
                    color = ElectricCyan.copy(alpha = 0.90f),
                    radius = 8.8f * scale,
                    center = pt(frame.h),
                    style = Stroke(width = 1.6f * scale)
                )

                // Crisp skeletal joint pins
                listOf(frame.s, frame.e, frame.w, frame.hp, frame.k, frame.a).forEach { jointPt ->
                    val jp = pt(jointPt)
                    drawCircle(
                        color = ObsidianDeep,
                        radius = 3.0f * scale,
                        center = jp
                    )
                    drawCircle(
                        color = ElectricCyan.copy(alpha = 0.85f),
                        radius = 2.0f * scale,
                        center = jp
                    )
                }

                // Subtle muscle activation markers (low-glare precision rings)
                val anchors = ExerciseData.muscleAnchors[pose].orEmpty()
                for (anchor in anchors) {
                    val ja = frame.joint(anchor.jointA)
                    val jb = frame.joint(anchor.jointB)
                    val cx = ja.first + (jb.first - ja.first) * anchor.t
                    val cy = ja.second + (jb.second - ja.second) * anchor.t
                    val center = pt(cx to cy)
                    val pct = muscleActivation[anchor.muscleKey] ?: 18
                    val fillAlpha = (0.05f + 0.16f * pct / 100f).coerceIn(0.05f, 0.22f)
                    val ringAlpha = (0.20f + 0.25f * pct / 100f).coerceIn(0.18f, 0.46f)
                    val rad = (anchor.radius * 0.54f) * scale * muscleScale

                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(NeonLime.copy(alpha = fillAlpha * 0.6f), NeonLime.copy(alpha = 0f)),
                            center = center,
                            radius = rad * 1.35f
                        ),
                        radius = rad * 1.35f,
                        center = center
                    )
                    drawCircle(
                        color = NeonLime.copy(alpha = fillAlpha),
                        radius = rad,
                        center = center
                    )
                    drawCircle(
                        color = NeonLime.copy(alpha = ringAlpha),
                        radius = rad,
                        center = center,
                        style = Stroke(width = 1.1f * scale)
                    )
                }

                // Joint angle telemetry
                val elbowDeg = jointAngleDeg(frame.s, frame.e, frame.w)
                val kneeDeg = jointAngleDeg(frame.hp, frame.k, frame.a)
                val angleStyle = TextStyle(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan
                )
                val elbPos = pt((frame.e.first + 7f).coerceAtMost(142f) to (frame.e.second - 10f).coerceAtLeast(14f))
                val knePos = pt((frame.k.first + 7f).coerceAtMost(142f) to (frame.k.second - 10f).coerceAtLeast(14f))

                drawText(textMeasurer, "$elbLabel $elbowDeg°", topLeft = elbPos, style = angleStyle)
                drawText(textMeasurer, "$kneLabel $kneeDeg°", topLeft = knePos, style = angleStyle)
                drawText(
                    textMeasurer,
                    musFooter,
                    topLeft = Offset(offsetX + 8f * scale, offsetY + 186f * scale),
                    style = TextStyle(
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonLime.copy(alpha = 0.85f)
                    )
                )
            }

            this@Column.AnimatedVisibility(
                visible = showFormWarn && formCue.isNotBlank(),
                enter = fadeIn() + scaleIn(initialScale = 0.9f),
                exit = fadeOut() + scaleOut(targetScale = 0.9f),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 18.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AlertAmber.copy(alpha = 0.22f),
                    border = BorderStroke(1.dp, AlertAmber)
                ) {
                    Text(
                        text = formCue.take(54),
                        style = MaterialTheme.typography.labelSmall,
                        color = AlertAmber,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (externalPlaying == null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(NeonLime.copy(alpha = 0.08f))
                        .border(1.dp, NeonLime.copy(alpha = 0.5f), CircleShape)
                        .clickable { playing = !playing }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                        .testTag("${tagPrefix}_play_button")
                ) {
                    Icon(
                        imageVector = if (effectivePlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (effectivePlaying) StringsData.pause.get(language) else StringsData.play.get(language),
                        tint = NeonLime,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (effectivePlaying) StringsData.pause.get(language) else StringsData.play.get(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonLime
                    )
                }
            }

            Text(
                text = "${StringsData.rep.get(language)} $reps" + if (targetReps > 0) " / $targetReps" else "",
                style = MaterialTheme.typography.labelMedium,
                color = ElectricCyan
            )

            Text(
                text = "${StringsData.tempoLbl.get(language)} ${tempoSec}s",
                style = MaterialTheme.typography.labelMedium,
                color = TextDim
            )

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.dp, GlassBorder, CircleShape)
                    .clickable {
                        playing = false
                        phase = 0f
                        reps = 0
                        showFormWarn = false
                    }
                    .testTag("${tagPrefix}_reset_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = "Reset animation",
                    tint = TextDim,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun AnimatedNeonBar(
    label: String,
    percent: Int,
    accent: Color = NeonLime,
    modifier: Modifier = Modifier
) {
    val targetFraction = (percent.coerceIn(0, 100) / 100f)
    val animatedFraction by animateFloatAsState(
        targetValue = targetFraction,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "bar_$label"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = TextPrimary
            )
            Text(
                text = "$percent%",
                style = MaterialTheme.typography.labelMedium,
                color = accent
            )
        }
        Spacer(modifier = Modifier.height(5.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.White.copy(alpha = 0.08f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedFraction)
                    .height(6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(accent)
            )
        }
    }
}
