package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.DispatcherProvider
import com.example.core.KineticFeedbackManager
import com.example.data.StringsData
import com.example.di.AppContainer
import com.example.domain.repository.NutritionRepository
import com.example.domain.repository.TrainingRepository
import com.example.domain.repository.UserProgressRepository
import com.example.domain.usecase.CoachEngineUseCase
import com.example.domain.usecase.ComputeRecoveryUseCase
import com.example.domain.usecase.GenerateRegimenUseCase
import com.example.domain.usecase.ResolveExerciseEquipmentUseCase
import com.example.model.ActiveSessionState
import com.example.model.ApexUiState
import com.example.model.AppLanguage
import com.example.model.AppTab
import com.example.model.Equipment
import com.example.model.Exercise
import com.example.model.ExerciseCategory
import com.example.model.FactCategory
import com.example.model.NutrientGroup
import com.example.model.PsychState
import com.example.model.ResolvedWorkoutExercise
import com.example.model.SessionItem
import com.example.model.SessionPhase
import com.example.model.TensionZone
import com.example.model.WorkoutLogEntry
import com.example.model.WorkoutPlan
import com.example.model.ZoneStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class ApexViewModel(
    private val trainingRepository: TrainingRepository,
    private val nutritionRepository: NutritionRepository,
    private val userProgressRepository: UserProgressRepository,
    private val feedbackManager: KineticFeedbackManager,
    private val computeRecovery: ComputeRecoveryUseCase,
    private val generateRegimen: GenerateRegimenUseCase,
    private val resolveExerciseEquipment: ResolveExerciseEquipmentUseCase,
    private val coachEngine: CoachEngineUseCase,
    private val dispatchers: DispatcherProvider
) : ViewModel() {

    private val _uiState = MutableStateFlow(ApexUiState())
    val uiState: StateFlow<ApexUiState> = _uiState.asStateFlow()

    private var restTimerJob: Job? = null
    private var toastJob: Job? = null

    init {
        viewModelScope.launch {
            feedbackManager.isSpeaking.collect { speaking ->
                _uiState.update { it.copy(isSpeaking = speaking) }
            }
        }
        viewModelScope.launch {
            val loaded = withContext(dispatchers.io) {
                userProgressRepository.loadInitialState { psych, sleep, hrv, rhr, zones ->
                    computeRecovery(psych, sleep, hrv, rhr, zones)
                }
            }
            _uiState.value = loaded
        }
    }

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(tab = tab) }
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.language == AppLanguage.AR) AppLanguage.EN else AppLanguage.AR
        updateAndSave { it.copy(language = next) }
        showToast(if (next.isArabic) "تم التحويل إلى العربية" else "Switched to English")
    }

    fun toggleStreakDay(index: Int) {
        updateAndSave { s ->
            val updated = s.streakDays.toMutableList()
            if (index in updated.indices) updated[index] = !updated[index]
            s.copy(streakDays = updated)
        }
    }

    fun setProgramFilter(programId: String?) {
        _uiState.update { it.copy(programFilter = programId) }
    }

    fun setExerciseCategoryFilter(category: ExerciseCategory?) {
        _uiState.update { it.copy(exerciseCategoryFilter = category) }
    }

    fun setExerciseQuery(query: String) {
        _uiState.update { it.copy(exerciseQuery = query) }
    }

    fun openWorkout(workoutId: String?) {
        _uiState.update { it.copy(selectedWorkoutId = workoutId, selectedExerciseId = null) }
    }

    fun openExerciseGuide(exerciseId: String?) {
        _uiState.update { it.copy(selectedExerciseId = exerciseId) }
    }

    fun setPsychState(psych: PsychState) {
        updateAndSave { s ->
            val rec = computeRecovery(psych, s.sleepHours, s.hrvMs, s.rhrBpm, s.zones)
            s.copy(psych = psych, recoveryPercent = rec)
        }
    }

    fun updateSleep(hours: Float) {
        val snapped = ((hours * 4f).roundToInt() / 4f).coerceIn(4f, 10f)
        updateAndSave { s ->
            val rec = computeRecovery(s.psych, snapped, s.hrvMs, s.rhrBpm, s.zones)
            s.copy(sleepHours = snapped, recoveryPercent = rec)
        }
    }

    fun updateHrv(hrv: Int) {
        val clamped = hrv.coerceIn(30, 100)
        updateAndSave { s ->
            val rec = computeRecovery(s.psych, s.sleepHours, clamped, s.rhrBpm, s.zones)
            s.copy(hrvMs = clamped, recoveryPercent = rec)
        }
    }

    fun updateRhr(rhr: Int) {
        val clamped = rhr.coerceIn(40, 70)
        updateAndSave { s ->
            val rec = computeRecovery(s.psych, s.sleepHours, s.hrvMs, clamped, s.zones)
            s.copy(rhrBpm = clamped, recoveryPercent = rec)
        }
    }

    fun cycleZone(zone: TensionZone) {
        updateAndSave { s ->
            val nextZones = s.zones.toMutableMap()
            nextZones[zone] = (nextZones[zone] ?: ZoneStatus.FRESH).next()
            val rec = computeRecovery(s.psych, s.sleepHours, s.hrvMs, s.rhrBpm, nextZones)
            s.copy(zones = nextZones, recoveryPercent = rec)
        }
    }

    fun toggleEquipment(eq: Equipment) {
        updateAndSave { s ->
            val updated = if (eq == Equipment.NONE) {
                emptySet()
            } else {
                val m = s.ownedEquipment.toMutableSet()
                if (eq in m) m.remove(eq) else m.add(eq)
                m
            }
            s.copy(ownedEquipment = updated)
        }
    }

    fun applyAndGenerateRegimen() {
        val s = _uiState.value
        val recovery = computeRecovery(s.psych, s.sleepHours, s.hrvMs, s.rhrBpm, s.zones)
        val regimen = generateRegimen(recovery, s.psych, s.ownedEquipment)
        updateAndSave { it.copy(recoveryPercent = recovery, regimen = regimen, tab = AppTab.WORKOUTS) }
        showToast(StringsData.regenOk.get(_uiState.value.language))
    }

    fun toggleVoiceHud() {
        val next = !_uiState.value.voiceEnabled
        if (!next) {
            feedbackManager.stopSpeaking()
        }
        updateAndSave { it.copy(voiceEnabled = next, isSpeaking = if (next) it.isSpeaking else false) }
        val lang = _uiState.value.language
        showToast(if (next) StringsData.voiceEnabledToast.get(lang) else StringsData.voiceDisabledToast.get(lang))
    }

    fun applyShoulderSwap() {
        updateAndSave { it.copy(swappedShoulderProtocol = true) }
        showToast(StringsData.swapApplied.get(_uiState.value.language))
    }

    fun sendChatMessage(rawText: String) {
        val pair = coachEngine(rawText, _uiState.value.recoveryPercent) ?: return
        val (userMsg, replyMsg) = pair
        updateAndSave { it.copy(chatMessages = it.chatMessages + userMsg + replyMsg) }
        val spoken = replyMsg.text ?: if (replyMsg.isSwapCard) StringsData.coachSwap else null
        if (spoken != null && _uiState.value.voiceEnabled) {
            feedbackManager.speak(spoken.get(_uiState.value.language), _uiState.value.language.isArabic)
        }
    }

    fun addWater250() {
        updateAndSave { s ->
            s.copy(waterMl = (s.waterMl + 250).coerceAtMost(4000))
        }
    }

    fun logRecipe(index: Int) {
        val recipe = nutritionRepository.getRecipeAt(index) ?: return
        updateAndSave { s ->
            s.copy(
                loggedMacros = s.loggedMacros.copy(
                    kcal = s.loggedMacros.kcal + recipe.kcal,
                    proteinG = s.loggedMacros.proteinG + recipe.proteinG,
                    carbsG = s.loggedMacros.carbsG + recipe.carbsG,
                    fatsG = s.loggedMacros.fatsG + recipe.fatsG
                )
            )
        }
        val lang = _uiState.value.language
        showToast("${StringsData.loggedTo.get(lang)} · ${recipe.name.get(lang)}")
    }

    fun setFactQuery(query: String) {
        _uiState.update { it.copy(factQuery = query) }
    }

    fun setFactCategoryFilter(category: FactCategory?) {
        _uiState.update { it.copy(factCategoryFilter = category) }
    }

    fun setNutrientFilter(group: NutrientGroup?) {
        _uiState.update { it.copy(nutrientFilter = group) }
    }

    fun addToCart(gearIndex: Int) {
        val item = nutritionRepository.getGearItemAt(gearIndex) ?: return
        updateAndSave { it.copy(cartIndices = it.cartIndices + gearIndex) }
        val lang = _uiState.value.language
        showToast("${StringsData.addedTo.get(lang)} · ${item.name.get(lang)}")
    }

    fun clearCart() {
        updateAndSave { it.copy(cartIndices = emptyList()) }
    }

    fun showNoAlertsToast() {
        showToast(StringsData.noAlerts.get(_uiState.value.language))
    }

    fun resolveExercise(exerciseId: String, state: ApexUiState = _uiState.value): Exercise =
        resolveExerciseEquipment.resolveExercise(
            exerciseId = exerciseId,
            ownedEquipment = state.ownedEquipment,
            swappedShoulderProtocol = state.swappedShoulderProtocol
        )

    fun resolveWorkoutExercises(
        workout: WorkoutPlan,
        state: ApexUiState = _uiState.value
    ): List<ResolvedWorkoutExercise> =
        resolveExerciseEquipment.resolveWorkoutExercises(
            workout = workout,
            ownedEquipment = state.ownedEquipment,
            swappedShoulderProtocol = state.swappedShoulderProtocol
        )

    fun heroWorkout(state: ApexUiState = _uiState.value): WorkoutPlan {
        val id = state.regimen?.workoutId ?: "planche"
        return trainingRepository.getWorkoutById(id) ?: trainingRepository.getWorkouts().first()
    }

    /* ======== LIVE GUIDED SESSION ======== */

    fun startWorkoutSession(workoutId: String) {
        val wo = trainingRepository.getWorkoutById(workoutId) ?: return
        val resolved = resolveWorkoutExercises(wo)
        val seq = buildList {
            resolved.forEach { rx ->
                for (setNum in 1..rx.sets) {
                    add(SessionItem(rx, setNum))
                }
            }
        }
        restTimerJob?.cancel()
        _uiState.update {
            it.copy(
                selectedWorkoutId = null,
                selectedExerciseId = null,
                activeSession = ActiveSessionState(
                    workout = wo,
                    sequence = seq,
                    currentIndex = 0,
                    phase = SessionPhase.WORK,
                    isPlayingFigure = true
                )
            )
        }
    }

    fun onSessionRepCompleted(newRep: Int) {
        feedbackManager.playRepBeep()
        val session = _uiState.value.activeSession ?: return
        val item = session.sequence.getOrNull(session.currentIndex) ?: return
        if (newRep >= item.exercise.reps) {
            finishCurrentSessionSet()
        } else {
            _uiState.update { s ->
                s.activeSession?.let { active ->
                    s.copy(activeSession = active.copy(currentReps = newRep))
                } ?: s
            }
        }
    }

    fun finishCurrentSessionSet() {
        val session = _uiState.value.activeSession ?: return
        val currentItem = session.sequence.getOrNull(session.currentIndex) ?: return
        val nextIndex = session.currentIndex + 1
        if (nextIndex >= session.sequence.size) {
            completeSession()
            return
        }
        val restSec = currentItem.exercise.restSec
        _uiState.update { s ->
            s.copy(
                activeSession = session.copy(
                    currentIndex = nextIndex,
                    phase = SessionPhase.REST,
                    restSecondsLeft = restSec,
                    isPlayingFigure = false,
                    currentReps = 0
                )
            )
        }
        startRestCountdown()
    }

    fun skipSessionRest() {
        restTimerJob?.cancel()
        val session = _uiState.value.activeSession ?: return
        _uiState.update {
            it.copy(
                activeSession = session.copy(
                    phase = SessionPhase.WORK,
                    restSecondsLeft = 0,
                    isPlayingFigure = !session.isPaused,
                    currentReps = 0
                )
            )
        }
    }

    fun toggleSessionPause() {
        val session = _uiState.value.activeSession ?: return
        val nextPaused = !session.isPaused
        _uiState.update {
            it.copy(
                activeSession = session.copy(
                    isPaused = nextPaused,
                    isPlayingFigure = !nextPaused && session.phase == SessionPhase.WORK
                )
            )
        }
    }

    fun endWorkoutSession() {
        restTimerJob?.cancel()
        _uiState.update { it.copy(activeSession = null) }
    }

    private fun startRestCountdown() {
        restTimerJob?.cancel()
        restTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val session = _uiState.value.activeSession ?: break
                if (session.phase != SessionPhase.REST) break
                if (session.isPaused) continue
                val nextLeft = session.restSecondsLeft - 1
                if (nextLeft <= 0) {
                    skipSessionRest()
                    break
                } else {
                    _uiState.update { s ->
                        s.activeSession?.let { active ->
                            s.copy(activeSession = active.copy(restSecondsLeft = nextLeft))
                        } ?: s
                    }
                }
            }
        }
    }

    private fun completeSession() {
        restTimerJob?.cancel()
        val session = _uiState.value.activeSession ?: return
        val now = System.currentTimeMillis()
        val logEntry = WorkoutLogEntry(
            id = "log_$now",
            workoutId = session.workout.id,
            title = session.workout.title,
            kcal = session.workout.kcal,
            setsCompleted = session.sequence.size,
            completedAtMillis = now
        )
        updateAndSave { s ->
            val days = s.streakDays.toMutableList()
            if (days.size > 4) days[4] = true
            s.copy(
                streakDays = days,
                workoutHistory = listOf(logEntry) + s.workoutHistory,
                activeSession = session.copy(
                    phase = SessionPhase.COMPLETE,
                    isPlayingFigure = false
                )
            )
        }
    }

    private fun updateAndSave(transform: (ApexUiState) -> ApexUiState) {
        _uiState.update(transform)
        val snapshot = _uiState.value
        viewModelScope.launch(dispatchers.io) {
            userProgressRepository.saveState(snapshot)
        }
    }

    private fun showToast(msg: String) {
        toastJob?.cancel()
        _uiState.update { it.copy(toastMessage = msg) }
        toastJob = viewModelScope.launch {
            delay(2100L)
            _uiState.update { it.copy(toastMessage = null) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        restTimerJob?.cancel()
        feedbackManager.release()
    }

    companion object {
        fun provideFactory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ApexViewModel(
                        trainingRepository = container.trainingRepository,
                        nutritionRepository = container.nutritionRepository,
                        userProgressRepository = container.userProgressRepository,
                        feedbackManager = container.feedbackManager,
                        computeRecovery = container.computeRecoveryUseCase,
                        generateRegimen = container.generateRegimenUseCase,
                        resolveExerciseEquipment = container.resolveExerciseUseCase,
                        coachEngine = container.coachEngineUseCase,
                        dispatchers = container.dispatchers
                    ) as T
                }
            }
    }
}
