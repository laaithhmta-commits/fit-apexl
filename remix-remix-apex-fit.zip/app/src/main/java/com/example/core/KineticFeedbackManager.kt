package com.example.core

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

interface KineticFeedbackManager {
    val isSpeaking: StateFlow<Boolean>
    fun speak(text: String, isArabic: Boolean)
    fun stopSpeaking()
    fun playRepBeep()
    fun release()
}

class AndroidKineticFeedbackManager(context: Context) :
    KineticFeedbackManager, TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private val _isSpeaking = MutableStateFlow(false)
    override val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var ttsReady = false
    private val tts: TextToSpeech? = runCatching {
        TextToSpeech(appContext, this)
    }.getOrNull()

    private val toneGen: ToneGenerator? = runCatching {
        ToneGenerator(AudioManager.STREAM_MUSIC, 60)
    }.getOrNull()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
        }
    }

    override fun speak(text: String, isArabic: Boolean) {
        if (!ttsReady || text.isBlank()) return
        runCatching {
            tts?.language = if (isArabic) Locale("ar", "SA") else Locale.US
            tts?.setSpeechRate(1.0f)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), "apex_${System.currentTimeMillis()}")
        }
    }

    override fun stopSpeaking() {
        runCatching { tts?.stop() }
        _isSpeaking.value = false
    }

    override fun playRepBeep() {
        runCatching { toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 70) }
    }

    override fun release() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        runCatching { toneGen?.release() }
        _isSpeaking.value = false
    }
}
