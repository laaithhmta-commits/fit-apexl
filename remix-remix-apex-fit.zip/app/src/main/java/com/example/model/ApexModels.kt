package com.example.model

import androidx.annotation.DrawableRes

enum class AppLanguage(val code: String) {
    AR("ar"),
    EN("en");

    val isArabic: Boolean get() = this == AR

    companion object {
        fun fromCode(code: String?): AppLanguage =
            if (code == "en") EN else AR
    }
}

enum class AppTab {
    WORKOUTS, INTAKE, AI, NUTRITION, GEAR
}

data class BiText(
    val en: String,
    val ar: String
) {
    fun get(lang: AppLanguage): String = if (lang.isArabic) ar else en
}

data class BiList(
    val en: List<String>,
    val ar: List<String>
) {
    fun get(lang: AppLanguage): List<String> = if (lang.isArabic) ar else en
}

enum class PoseType(val key: String) {
    PUSHUP("pushup"),
    SQUAT("squat"),
    PULLUP("pullup"),
    PLANK("plank"),
    LUNGE("lunge"),
    PIKE("pike"),
    RAISE("raise"),
    SIT("sit")
}

enum class ExerciseCategory(val id: String) {
    CHEST("chest"),
    BACK("back"),
    SHOULDERS("shoulders"),
    LEGS("legs"),
    CORE("core"),
    HIIT("hiit")
}

enum class Equipment(val id: String) {
    NONE("none"),
    BAR("bar"),
    TOWEL("towel"),
    CHAIR("chair"),
    DOOR("door")
}

data class Exercise(
    val id: String,
    val category: ExerciseCategory,
    val pose: PoseType,
    val name: BiText,
    val primaryMuscles: List<String>,
    val secondaryMuscles: List<String>,
    val requiredEquipment: List<Equipment>,
    val fallbackId: String?,
    val steps: BiList,
    val mistakes: BiList,
    val levels: BiList
)

data class WorkoutExerciseSpec(
    val exerciseId: String,
    val sets: Int,
    val reps: Int,
    val tempoSec: Float,
    val restSec: Int
)

data class ResolvedWorkoutExercise(
    val exercise: Exercise,
    val sets: Int,
    val reps: Int,
    val tempoSec: Float,
    val restSec: Int
)

enum class WorkoutLevel(val key: String) {
    ADVANCED("Advanced"),
    INTERMEDIATE("Intermediate"),
    RECOVERY("Recovery")
}

data class WorkoutPlan(
    val id: String,
    val programId: String,
    val title: BiText,
    val durationMin: Int,
    val kcal: Int,
    val level: WorkoutLevel,
    val cue: BiText,
    val muscles: Map<String, Int>,
    val exercises: List<WorkoutExerciseSpec>
)

data class TrainingProgram(
    val id: String,
    val name: BiText,
    val workoutIds: List<String>
)

data class RecipeNutrition(
    val serving: BiText,
    val fiberG: Int,
    val sodiumMg: Int,
    val sugarG: Int
)

data class Recipe(
    val id: String,
    val tag: String,
    val time: BiText,
    val prepMin: Int,
    val kcal: Int,
    val proteinG: Int,
    val carbsG: Int,
    val fatsG: Int,
    @DrawableRes val imageRes: Int,
    val name: BiText,
    val benefit: BiText,
    val nutrition: RecipeNutrition,
    val basics: BiText,
    val ingredients: List<BiText>,
    val steps: BiList
)

enum class NutrientGroup(val id: String) {
    MACRO("macro"),
    VITAMIN("vitamin"),
    MINERAL("mineral")
}

data class NutrientGuideItem(
    val id: String,
    val group: NutrientGroup,
    val name: BiText,
    val subtitle: BiText,
    val role: BiText,
    val dailyTarget: BiText,
    val foodSources: BiText,
    val absorptionTip: BiText
)

enum class FactCategory(val index: Int) {
    MUSCLE_SYNTHESIS(0),
    FAT_LOSS(1),
    GUT_ABSORPTION(2),
    JOINT_RECOVERY(3),
    BRAIN_FOCUS(4)
}

data class FoodFact(
    val number: Int,
    val category: FactCategory,
    val title: BiText,
    val body: BiText
)

data class GearItem(
    val id: Int,
    val name: BiText,
    val category: BiText,
    val priceUsd: Int,
    val specs: BiList
)

enum class PsychState(val key: String, val delta: Int) {
    DRAINED("Drained", -12),
    FATIGUED("Fatigued", -7),
    NEUTRAL("Neutral", 0),
    FOCUSED("Focused", 4),
    PEAK("Peak", 6)
}

enum class ZoneStatus(val key: String, val pct: Int) {
    FRESH("Fresh", 96),
    READY("Ready", 90),
    MILD_SORENESS("Mild Soreness", 70),
    SORE("Sore", 45);

    fun next(): ZoneStatus {
        val values = entries
        return values[(ordinal + 1) % values.size]
    }
}

enum class TensionZone(val key: String) {
    CHEST("chest"),
    HAMS("hams"),
    LOWER("lower")
}

enum class RegimenLevel(val key: String) {
    DELOAD("Deload"),
    BUILD("Build"),
    MAINTAIN("Maintain")
}

data class UserRegimen(
    val level: RegimenLevel,
    val workoutId: String,
    val note: BiText
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: BiText? = null,
    val isSwapCard: Boolean = false
)

data class LoggedMacros(
    val kcal: Int = 0,
    val proteinG: Int = 0,
    val carbsG: Int = 0,
    val fatsG: Int = 0
)

data class WorkoutLogEntry(
    val id: String,
    val workoutId: String,
    val title: BiText,
    val kcal: Int,
    val setsCompleted: Int,
    val completedAtMillis: Long
)

data class SessionItem(
    val exercise: ResolvedWorkoutExercise,
    val setNumber: Int
)

enum class SessionPhase {
    WORK, REST, COMPLETE
}

data class ActiveSessionState(
    val workout: WorkoutPlan,
    val sequence: List<SessionItem>,
    val currentIndex: Int = 0,
    val phase: SessionPhase = SessionPhase.WORK,
    val restSecondsLeft: Int = 0,
    val isPaused: Boolean = false,
    val isPlayingFigure: Boolean = true,
    val currentReps: Int = 0
)

data class ApexUiState(
    val tab: AppTab = AppTab.WORKOUTS,
    val language: AppLanguage = AppLanguage.AR,
    val psych: PsychState = PsychState.FOCUSED,
    val sleepHours: Float = 7.75f,
    val hrvMs: Int = 62,
    val rhrBpm: Int = 48,
    val recoveryPercent: Int = 87,
    val zones: Map<TensionZone, ZoneStatus> = mapOf(
        TensionZone.CHEST to ZoneStatus.FRESH,
        TensionZone.HAMS to ZoneStatus.MILD_SORENESS,
        TensionZone.LOWER to ZoneStatus.READY
    ),
    val ownedEquipment: Set<Equipment> = setOf(Equipment.BAR, Equipment.TOWEL),
    val swappedShoulderProtocol: Boolean = false,
    val regimen: UserRegimen? = null,
    val streakDays: List<Boolean> = listOf(true, true, true, true, true, false, false),
    val loggedMacros: LoggedMacros = LoggedMacros(),
    val waterMl: Int = 3200,
    val workoutHistory: List<WorkoutLogEntry> = emptyList(),
    val factQuery: String = "",
    val factCategoryFilter: FactCategory? = null,
    val nutrientFilter: NutrientGroup? = null,
    val programFilter: String? = null,
    val exerciseCategoryFilter: ExerciseCategory? = null,
    val exerciseQuery: String = "",
    val cartIndices: List<Int> = emptyList(),
    val voiceEnabled: Boolean = false,
    val isSpeaking: Boolean = false,
    val chatMessages: List<ChatMessage> = defaultChat(),
    val selectedWorkoutId: String? = null,
    val selectedExerciseId: String? = null,
    val activeSession: ActiveSessionState? = null,
    val toastMessage: String? = null
) {
    companion object {
        fun defaultChat(): List<ChatMessage> = listOf(
            ChatMessage(
                id = "init_u",
                isUser = true,
                text = BiText(
                    en = "My right shoulder felt pinch during handstand push-ups yesterday. How should I adjust today?",
                    ar = "شعرت بوخزة في كتفي الأيمن أثناء ضغط الوقوف على اليدين أمس. كيف أعدّل تمرين اليوم؟"
                )
            ),
            ChatMessage(
                id = "init_b",
                isUser = false,
                isSwapCard = true
            )
        )
    }
}
