package com.example.data

import com.example.model.AppLanguage
import com.example.model.BiText
import com.example.model.Equipment
import com.example.model.ExerciseCategory
import com.example.model.FactCategory
import com.example.model.NutrientGroup
import com.example.model.PsychState
import com.example.model.RegimenLevel
import com.example.model.TensionZone
import com.example.model.WorkoutLevel
import com.example.model.ZoneStatus

object StringsData {
    val live = BiText("LIVE HUD", "الواجهة الحية")
    val tabWorkouts = BiText("Workouts", "التمارين")
    val tabIntake = BiText("Intake", "التقييم")
    val tabAI = BiText("AI HUD", "المدرب")
    val tabNutrition = BiText("Nutrition", "التغذية")
    val tabGear = BiText("Gear", "المعدات")

    val kineticEyebrow = BiText("TODAY'S KINETIC PROTOCOL", "بروتوكول اليوم الحركي")
    val engineTitle = BiText("Calisthenics Engine", "محرك الكالستنكس")
    val lvlBadge = BiText("LVL 4 · HYPERTROPHY", "المستوى 4 · تضخيم")
    val streak = BiText("DAYS STREAK · TOP 4% CONSISTENCY", "يوم متتالي · أفضل 4% التزاماً")
    val bioSynced = BiText("BIOMETRICS SYNCED", "القياسات الحيوية متزامنة")
    val bpm = BiText("BPM", "نبضة/د")

    val directiveTitle = BiText("APEX AI DAILY DIRECTIVE", "توجيه المدرب اليومي")
    val directive = BiText(
        "\"Consistency beats intensity, but intensity crowns the champion. Lock each rep with surgical intent.\"",
        "\"الاستمرارية تتفوق على الشدة، لكن الشدة تتوّج البطل. نفّذ كل تكرار بدقة جراحية.\""
    )
    val coachName = BiText("— Coach Marcus Van Dyke", "— المدرب ماركوس فان دايك")
    val regimenTitle = BiText("TODAY'S REGIMEN", "نظام اليوم")
    val priority = BiText("PRIORITY PROTOCOL", "بروتوكول الأولوية")
    val min = BiText("MIN", "دقيقة")
    val kcal = BiText("KCAL", "سعرة")
    val startWorkout = BiText("START KINETIC WORKOUT →", "ابدأ التمرين الحركي ←")
    val formCaution = BiText("FORM CAUTION REMINDER", "تنبيه الوضعية")

    val programs = BiText("Elite Training Programs", "برامج التدريب النخبوية")
    val all = BiText("All", "الكل")
    val plans = BiText("PLANS", "خطط")
    val exCount = BiText("exercises", "تمارين")
    val libraryTitle = BiText("Home Exercise Library · Men", "مكتبة تمارين المنزل · للرجال")
    val libraryNote = BiText(
        "Bodyweight & minimal-gear only. No gym machines, barbells or cables.",
        "وزن الجسم ومعدات بسيطة فقط. بدون أجهزة الصالة أو البار أو الكابلات."
    )
    val searchEx = BiText("Search exercises", "ابحث عن تمرين")
    val tip = BiText("Tap any exercise to open its full guide.", "اضغط أي تمرين لفتح دليله الكامل.")

    val setup = BiText("Setup", "الإعداد")
    val execution = BiText("Execution", "التنفيذ")
    val breathing = BiText("Breathing", "التنفس")
    val mistakes = BiText("Common mistakes", "أخطاء شائعة")
    val progressions = BiText("Progression levels", "مستويات التطور")
    val beginner = BiText("BEGINNER", "مبتدئ")
    val intermediate = BiText("INTERMEDIATE", "متوسط")
    val advanced = BiText("ADVANCED", "متقدم")
    val primary = BiText("PRIMARY", "أساسي")
    val secondary = BiText("SECONDARY", "ثانوي")
    val close = BiText("Close", "إغلاق")

    val sets = BiText("SETS", "مجموعات")
    val reps = BiText("REPS", "تكرارات")
    val tempo = BiText("TEMPO", "الإيقاع")
    val rest = BiText("REST", "الراحة")
    val halfRep = BiText("s / half-rep", "ث / نصف تكرار")
    val play = BiText("PLAY", "تشغيل")
    val pause = BiText("PAUSE", "إيقاف")
    val resume = BiText("RESUME", "استئناف")
    val liveSkeletal = BiText("LIVE SKELETAL", "الهيكل الحي")
    val formOk = BiText("FORM: OPTIMAL", "الوضعية: مثالية")
    val formCheck = BiText("FORM: CHECK", "الوضعية: راجع")
    val rep = BiText("REP", "تكرار")
    val tempoLbl = BiText("TEMPO", "الإيقاع")
    val musAct = BiText("MUSCLE ACTIVATION · TELEMETRY", "تفعيل العضلات · القياس")
    val elb = BiText("ELB", "الكوع")
    val kne = BiText("KNE", "الركبة")

    val intakeEyebrow = BiText("DYNAMIC ALGORITHMIC CALIBRATION", "معايرة ديناميكية ذكية")
    val intakeTitle = BiText("Intake", "التقييم اليومي")
    val intakeNote = BiText(
        "Dynamic calibration for today's session based on current neuro-muscular strain.",
        "معايرة ديناميكية لجلسة اليوم بناءً على الإجهاد العصبي العضلي الحالي."
    )
    val psyState = BiText("Psychological State", "الحالة النفسية")
    val recovery = BiText("RECOVERY", "الاستشفاء")
    val autonomic = BiText("AUTONOMIC RECOVERY", "الاستشفاء الذاتي")
    val sleepArch = BiText("Sleep architecture", "بنية النوم")
    val sleepLbl = BiText("Sleep", "النوم")
    val hrvLbl = BiText("HRV", "تغيّر النبض")
    val rhrLbl = BiText("Resting HR", "نبض الراحة")
    val deepSleep = BiText("sleep", "ساعة نوم")
    val tension = BiText("Biomechanical Tension", "التوتر الحركي")
    val zonesLogged = BiText("ZONES LOGGED", "مناطق مسجّلة")
    val tapZone = BiText("Tap a zone to cycle its status.", "اضغط المنطقة لتغيير حالتها.")
    val hardware = BiText("Hardware & Logistics", "المعدات والإمكانات")
    val multi = BiText("MULTI-SELECT", "اختيار متعدد")
    val applyRegimen = BiText("APPLY & GENERATE TODAY'S REGIMEN", "طبّق وأنشئ نظام اليوم")

    val aiEyebrow = BiText("REAL-TIME BIOMECHANICAL & RECOVERY NEURAL ENGINE", "محرك حيوي ميكانيكي وعصبي للاستشفاء فوري")
    val aiTitle = BiText("APEX AI CORE", "نواة APEX الذكية")
    val telem = BiText("60 FPS TELEMETRY", "قياس 60 إطار/ث")
    val squatDepth = BiText("SQUAT DEPTH", "عمق القرفصاء")
    val parallel = BiText("PARALLEL", "متوازٍ")
    val kneeTrack = BiText("KNEE TRACKING", "تتبّع الركبة")
    val lumbar = BiText("Lumbar spine neutral & braced", "أسفل الظهر محايد ومشدود")
    val voiceHud = BiText("VOICE SYNTH HUD", "واجهة الصوت")
    val voiceOn = BiText("Real-time audio feedback enabled", "التعليق الصوتي الفوري مفعّل")
    val voiceOff = BiText("Real-time audio feedback disabled", "التعليق الصوتي الفوري معطّل")
    val composer = BiText("Ask Apex Biomechanics or Coach…", "اسأل المدرب أو محرك الحركة…")
    val send = BiText("Send", "إرسال")
    val coachHead = BiText("APEX NEURAL COACH", "مدرب APEX العصبي")
    val coachNow = BiText("APEX NEURAL COACH NOW", "مدرب APEX العصبي الآن")
    val swapTitle = BiText("Protocol Swap Ready", "تبديل البروتوكول جاهز")
    val swapSub = BiText("Updates today's active setlist", "يحدّث قائمة تمارين اليوم")
    val apply = BiText("APPLY", "تطبيق")
    val applied = BiText("APPLIED ✓", "تم التطبيق ✓")

    val fuelEyebrow = BiText("BIO-OPTIMIZED ANABOLIC MACRO HUD", "واجهة الماكروز البنائية المحسّنة")
    val fuelTitle = BiText("Fueling Strategy", "استراتيجية التغذية")
    val synced = BiText("SYNCED", "متزامن")
    val dailyGoal = BiText("DAILY CALORIC GOAL", "الهدف اليومي من السعرات")
    val protein = BiText("PROTEIN", "بروتين")
    val carbs = BiText("CARBS", "كربوهيدرات")
    val fats = BiText("FATS", "دهون")
    val hydration = BiText("HYDRATION STATUS", "حالة الترطيب")
    val add250 = BiText("+ 250 ml", "+ 250 مل")
    val queue = BiText("Anabolic Queue", "طابور التغذية البنائية")
    val log = BiText("LOG", "سجّل")
    val loggedTo = BiText("Logged", "تم التسجيل")
    val prep = BiText("prep", "تحضير")
    val recipe = BiText("Recipes", "الوصفات")
    val ingredients = BiText("Ingredients", "المكونات")
    val method = BiText("Preparation", "طريقة التحضير")
    val nutritionFacts = BiText("Nutrition & basics", "القيم الغذائية والمعلومات الأساسية")
    val serving = BiText("Serving", "الحصة")
    val fiber = BiText("Fibre", "ألياف")
    val sodium = BiText("Sodium", "صوديوم")
    val sugar = BiText("Sugar", "سكر")
    val basics = BiText("Basic info", "معلومات أساسية")
    val recipeBenefit = BiText("Key Benefit", "فائدة الوصفة")
    val academyTitle = BiText("Learn Nutrition · Macros & Micros", "تعلّم التغذية · المغذيات الكبرى والصغرى")
    val academySubtitle = BiText(
        "Complete guide to macronutrients, vitamins and minerals — what they do, daily needs and where to find them.",
        "دليل شامل للمغذيات الكبرى والصغرى (الفيتامينات والمعادن) — دورها في الجسم، احتياجك اليومي، وأين توجد."
    )
    val nutrientRole = BiText("Function in Body", "الدور الحيوي والفائدة")
    val nutrientTarget = BiText("Daily Target", "الاحتياج اليومي")
    val nutrientSources = BiText("Where It's Found", "أين يوجد (أهم المصادر)")
    val nutrientTip = BiText("Absorption & Timing Tip", "نصيحة الامتصاص والتوقيت")
    val factsTitle = BiText("100 Bio-Synergy Food Facts", "100 حقيقة عن تآزر الأطعمة")
    val searchFacts = BiText("Search facts, foods or nutrients", "ابحث في الحقائق أو الأطعمة أو العناصر")
    val spotlight = BiText("DAILY SYNERGY SPOTLIGHT", "حقيقة اليوم")
    val showing = BiText("SHOWING", "عرض")
    val of = BiText("OF", "من")
    val noFacts = BiText("No results match your search.", "لا توجد نتائج تطابق بحثك.")

    val gearEyebrow = BiText("PRO PERFORMANCE EQUIPMENT", "معدات الأداء الاحترافي")
    val gearTitle = BiText("Gear", "المعدات")
    val inCart = BiText("IN CART", "في السلة")
    val addCart = BiText("ADD TO CART", "أضف إلى السلة")
    val cartLbl = BiText("CART", "السلة")
    val emptyCart = BiText("Your cart is empty.", "سلتك فارغة.")
    val clearCart = BiText("CLEAR CART", "إفراغ السلة")
    val usd = BiText("Prices shown in US dollars (USD).", "الأسعار بالدولار الأمريكي (USD).")

    val sessDone = BiText("SESSION COMPLETE", "اكتملت الجلسة")
    val locked = BiText("Locked in.", "تم الإنجاز.")
    val sessSets = BiText("sets logged", "مجموعات مسجّلة")
    val finish = BiText("FINISH", "إنهاء")
    val endSession = BiText("End session", "إنهاء الجلسة")
    val work = BiText("WORK", "عمل")
    val restLbl = BiText("REST", "راحة")
    val pauseSession = BiText("PAUSE SESSION", "إيقاف الجلسة")
    val formCue = BiText("FORM CUE", "إشارة الوضعية")
    val skipRest = BiText("SKIP REST →", "تخطي الراحة ←")
    val completeSet = BiText("COMPLETE SET ✓", "إتمام المجموعة ✓")

    val regenOk = BiText("Regimen generated", "تم إنشاء النظام")
    val noAlerts = BiText("No new alerts", "لا توجد تنبيهات جديدة")
    val voiceEnabledToast = BiText("Voice HUD enabled", "تم تفعيل الصوت")
    val voiceDisabledToast = BiText("Voice HUD disabled", "تم إيقاف الصوت")
    val swapApplied = BiText("Protocol swap applied to today's setlist", "تم تطبيق التبديل على تمارين اليوم")
    val addedTo = BiText("Added", "أضيف")

    val sessionHistoryTitle = BiText("Session Telemetry Log", "سجل الجلسات المكتملة")
    val sessionsCompleted = BiText("Sessions", "جلسات")
    val totalBurned = BiText("Total burned", "إجمالي الحرق")
    val totalSets = BiText("Total sets", "إجمالي المجموعات")
    val noSessionsYet = BiText(
        "Complete any guided workout to log calories and volume permanently.",
        "أكمل أي تمرين موجّه لتسجيل السعرات والحجم التدريبي بشكل دائم."
    )

    val aiQuickPrompts = listOf(
        BiText("Analyze Squat Video", "حلّل فيديو القرفصاء"),
        BiText("Form Check", "فحص الوضعية"),
        BiText("Optimize Recovery", "حسّن الاستشفاء"),
        BiText("Protein timing", "توقيت البروتين")
    )

    val coachSwap = BiText(
        "Likely impingement on the anterior delt during the bottom transition. Swap handstand push-ups for Deficit Pike Push-Ups with neutral wrist elevation, and add 3 sets of Scapular Wall Slides before starting.",
        "على الأرجح إجهاد في الجزء الأمامي من عضلة الكتف عند الانتقال للأسفل. استبدل ضغط الوقوف على اليدين بضغط الباي مع فرق الارتفاع، مع رفع الرسغين بوضعية محايدة، وأضف 3 مجموعات من انزلاق لوح الكتف على الحائط قبل البدء."
    )
    val coachForm = BiText(
        "Keep depth parallel or just below, knees tracking over the second toe, and chest up on the ascent. Film from the side at hip height and use Analyze Squat Video to check frame by frame.",
        "حافظ على عمق يوازي الأرض أو أعمق قليلاً، والركبتان تتبعان الإصبع الثاني، والصدر مرفوع عند الصعود. صوّر نفسك من الجانب على ارتفاع الحوض، واستخدم تحليل فيديو القرفصاء للمراجعة إطاراً بإطار."
    )
    val coachProtein = BiText(
        "Aim for about 25 g of protein within 40 minutes after training, paired with carbohydrates. The Nutrition tab shows today's remaining macros.",
        "استهدف نحو 25 غ من البروتين خلال 40 دقيقة بعد التمرين مع الكربوهيدرات. تبويب التغذية يعرض الماكروز المتبقية لليوم."
    )
    val coachDefault = BiText(
        "Tell me the movement, what you felt, and where. I will adjust the protocol with a precise cue, or offer a swap if a joint needs it.",
        "أخبرني بالحركة، وما الذي شعرت به، وأين. سأعدّل البروتوكول بإشارة دقيقة، أو أقترح تبديلاً إذا احتاج المفصل ذلك."
    )

    fun coachRecovery(recovery: Int) = BiText(
        "Recovery is at $recovery% today. Prioritise 7 hours or more of sleep, keep hydration on track, and finish with a 10-minute mobility flow before bed.",
        "الاستشفاء عند $recovery% اليوم. ركّز على 7 ساعات نوم أو أكثر، وحافظ على الترطيب، واختم بتدفق مرونة لمدة 10 دقائق قبل النوم."
    )

    fun muscleName(key: String, lang: AppLanguage): String = when (key) {
        "chest" -> BiText("Chest", "الصدر")
        "triceps" -> BiText("Triceps", "الثلاثية")
        "delts" -> BiText("Shoulders", "الأكتاف")
        "lats" -> BiText("Lats", "عضلات الظهر العريضة")
        "biceps" -> BiText("Biceps", "الثنائية")
        "traps" -> BiText("Traps", "الكتف العلوي")
        "core" -> BiText("Core", "البطن")
        "quads" -> BiText("Quads", "الفخذ الأمامي")
        "glutes" -> BiText("Glutes", "الأرداف")
        "hams" -> BiText("Hamstrings", "الخلفية")
        "calves" -> BiText("Calves", "السمانة")
        "obliques" -> BiText("Obliques", "الجوانب")
        "forearms" -> BiText("Forearms", "الساعد")
        "back" -> BiText("Lower back", "أسفل الظهر")
        "full" -> BiText("Full body", "الجسم كامل")
        else -> BiText(key, key)
    }.get(lang)

    fun categoryName(cat: ExerciseCategory, lang: AppLanguage): String = when (cat) {
        ExerciseCategory.CHEST -> BiText("Chest & Triceps", "الصدر والثلاثية")
        ExerciseCategory.BACK -> BiText("Back & Biceps", "الظهر والثنائية")
        ExerciseCategory.SHOULDERS -> BiText("Shoulders", "الأكتاف")
        ExerciseCategory.LEGS -> BiText("Legs & Glutes", "الساقين والأرداف")
        ExerciseCategory.CORE -> BiText("Core & Abs", "البطن والجذع")
        ExerciseCategory.HIIT -> BiText("HIIT & Conditioning", "الكارديو والـ HIIT")
    }.get(lang)

    fun workoutLevelName(level: WorkoutLevel, lang: AppLanguage): String = when (level) {
        WorkoutLevel.ADVANCED -> BiText("Advanced", "متقدم")
        WorkoutLevel.INTERMEDIATE -> BiText("Intermediate", "متوسط")
        WorkoutLevel.RECOVERY -> BiText("Recovery", "استشفاء")
    }.get(lang)

    fun regimenLevelName(level: RegimenLevel, lang: AppLanguage): String = when (level) {
        RegimenLevel.DELOAD -> BiText("Deload", "تخفيف الحمل")
        RegimenLevel.BUILD -> BiText("Build", "بناء")
        RegimenLevel.MAINTAIN -> BiText("Maintain", "حفاظ")
    }.get(lang)

    fun psychName(state: PsychState, lang: AppLanguage): String = when (state) {
        PsychState.DRAINED -> BiText("Drained", "منهك")
        PsychState.FATIGUED -> BiText("Fatigued", "متعب")
        PsychState.NEUTRAL -> BiText("Neutral", "محايد")
        PsychState.FOCUSED -> BiText("Focused", "مركّز")
        PsychState.PEAK -> BiText("Peak", "في الذروة")
    }.get(lang)

    fun zoneName(zone: TensionZone, lang: AppLanguage): String = when (zone) {
        TensionZone.CHEST -> BiText("Pectorals", "الصدر")
        TensionZone.HAMS -> BiText("Hamstrings", "الخلفية")
        TensionZone.LOWER -> BiText("Lower Back", "أسفل الظهر")
    }.get(lang)

    fun zoneStatusName(status: ZoneStatus, lang: AppLanguage): String = when (status) {
        ZoneStatus.FRESH -> BiText("Fresh", "جاهز بقوة")
        ZoneStatus.READY -> BiText("Ready", "جاهز")
        ZoneStatus.MILD_SORENESS -> BiText("Mild soreness", "ألم خفيف")
        ZoneStatus.SORE -> BiText("Sore", "متألم")
    }.get(lang)

    fun equipmentName(eq: Equipment, lang: AppLanguage): String = when (eq) {
        Equipment.NONE -> BiText("No Equipment", "بدون معدات")
        Equipment.BAR -> BiText("Pull-up Bar", "عارضة سحب")
        Equipment.TOWEL -> BiText("Towel", "منشفة")
        Equipment.CHAIR -> BiText("Sturdy Chair", "كرسي متين")
        Equipment.DOOR -> BiText("Table / Doorframe", "طاولة / إطار باب")
    }.get(lang)

    fun factCategoryName(cat: FactCategory, lang: AppLanguage): String = when (cat) {
        FactCategory.MUSCLE_SYNTHESIS -> BiText("Muscle Synthesis", "بناء العضلات")
        FactCategory.FAT_LOSS -> BiText("Fat Loss", "حرق الدهون")
        FactCategory.GUT_ABSORPTION -> BiText("Gut & Absorption", "الهضم والامتصاص")
        FactCategory.JOINT_RECOVERY -> BiText("Joint Recovery", "استشفاء المفاصل")
        FactCategory.BRAIN_FOCUS -> BiText("Brain Focus", "تركيز الدماغ")
    }.get(lang)

    fun nutrientGroupName(group: NutrientGroup, lang: AppLanguage): String = when (group) {
        NutrientGroup.MACRO -> BiText("Macronutrients", "المغذيات الكبرى")
        NutrientGroup.VITAMIN -> BiText("Vitamins", "الفيتامينات")
        NutrientGroup.MINERAL -> BiText("Minerals", "المعادن")
    }.get(lang)

    fun weekDays(lang: AppLanguage): List<String> =
        if (lang.isArabic) listOf("ن", "ث", "ر", "خ", "ج", "س", "أ")
        else listOf("M", "T", "W", "T", "F", "S", "S")
}
