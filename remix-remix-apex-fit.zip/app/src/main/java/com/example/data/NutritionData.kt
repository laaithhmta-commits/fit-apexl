package com.example.data

import com.example.R
import com.example.model.BiList
import com.example.model.BiText
import com.example.model.FactCategory
import com.example.model.FoodFact
import com.example.model.GearItem
import com.example.model.Recipe
import com.example.model.RecipeNutrition

object NutritionData {

    val recipes: List<Recipe> = listOf(
        Recipe(
            id = "salmon",
            tag = "MEAL #3",
            time = BiText("Post-workout · 15 min prep", "بعد التمرين · 15 دقيقة تحضير"),
            prepMin = 15,
            kcal = 640,
            proteinG = 48,
            carbsG = 60,
            fatsG = 22,
            imageRes = R.drawable.img_recipe_salmon_1795003130185,
            name = BiText("Wild Salmon & Quinoa Macro-Bowl", "وعاء السلمون البري والكينوا"),
            benefit = BiText(
                "Accelerates post-workout muscle repair with 48 g of complete protein, refills depleted muscle glycogen via slow-release quinoa, and lowers joint & muscle inflammation thanks to wild salmon omega-3s.",
                "يسرّع استشفاء العضلات بعد التمرين عبر 48 غ بروتين كامل، ويعوّض مخازن الجلايكوجين بكربوهيدرات الكينوا النظيفة، ويخفف التهاب المفاصل والعضلات بفضل أحماض أوميغا 3."
            ),
            nutrition = RecipeNutrition(BiText("1 bowl (≈520 g)", "وعاء واحد (≈520 غ)"), 9, 540, 6),
            basics = BiText(
                "Rich in EPA/DHA omega-3s. Complete protein. Best eaten 45 minutes after training. Keeps 2 days refrigerated.",
                "غني بأوميغا 3 (EPA/DHA) وبروتين كامل. يُفضّل تناوله بعد 45 دقيقة من التمرين. يُحفظ يومين في الثلاجة."
            ),
            ingredients = listOf(
                BiText("200 g wild sockeye salmon", "200 غ سلمون أحمر بري"),
                BiText("120 g cooked quinoa", "120 غ كينوا مطبوخة"),
                BiText("½ ripe avocado, sliced", "½ أفوكادو ناضج مقطّع"),
                BiText("A large handful of baby spinach", "حفنة كبيرة من السبانخ الصغيرة"),
                BiText("6 cherry tomatoes, halved", "6 طماطم كرزية مقسومة"),
                BiText("Juice of ½ lemon + 1 tbsp olive oil", "عصير ½ ليمونة + ملعقة كبيرة زيت زيتون"),
                BiText("Salt, black pepper, sesame seeds", "ملح، فلفل أسود، سمسم")
            ),
            steps = BiList(
                listOf(
                    "Season the salmon with salt and pepper, then sear skin-side down in a hot pan for 4 minutes.",
                    "Flip and cook 2 more minutes until just opaque in the centre.",
                    "Rinse and drain the quinoa, then warm it with a pinch of salt.",
                    "Whisk lemon juice and olive oil into a light vinaigrette.",
                    "Build the bowl with quinoa, spinach, tomatoes and avocado; top with salmon and dressing, then sprinkle sesame."
                ),
                listOf(
                    "تبّل السلمون بالملح والفلفل، ثم اشوه بالجلد للأسفل في مقلاة ساخنة لمدة 4 دقائق.",
                    "اقلبه واطهه دقيقتين إضافيتين حتى يصبح معتماً في المنتصف.",
                    "صفِّ الكينوا واغسلها، ثم سخّنها مع قليل من الملح.",
                    "اخفق عصير الليمون مع زيت الزيتون لصلصة خفيفة.",
                    "رتّب الوعاء بالكينوا والسبانخ والطماطم والأفوكادو، وضع السلمون والصلصة، ثم رش السمسم."
                )
            )
        ),
        Recipe(
            id = "matcha",
            tag = "PRE",
            time = BiText("T-30 min · 5 min prep", "قبل التمرين بـ 30 دقيقة · 5 دقائق تحضير"),
            prepMin = 5,
            kcal = 280,
            proteinG = 12,
            carbsG = 38,
            fatsG = 4,
            imageRes = R.drawable.img_recipe_matcha_1795003130742,
            name = BiText("Nitric Oxide Matcha Surge", "دفعة الماتشا لأكسيد النيتريك"),
            benefit = BiText(
                "Boosts blood flow and muscle pump via dietary nitrates, delivers jitter-free calm focus with caffeine + L-theanine, and gives fast pre-session energy without stomach heaviness.",
                "يعزز تدفق الدم والضخ العضلي عبر النترات الطبيعية، ويمنحك تركيزاً ذهنياً هادئاً دون توتر بفضل الكافيين والثيانين، مع طاقة سريعة خفيفة على المعدة قبل التمرين."
            ),
            nutrition = RecipeNutrition(BiText("1 drink (≈350 ml)", "مشروب واحد (≈350 مل)"), 3, 90, 14),
            basics = BiText(
                "Matcha has caffeine plus L-theanine for calm focus. Beetroot supplies dietary nitrate. Drink fresh; avoid within 6 hours of bedtime.",
                "الماتشا تحتوي على كافيين وثيانين لتركيز هادئ. الشمندر مصدر للنترات الغذائية. اشربه طازجاً، وتجنّبه قبل النوم بـ 6 ساعات."
            ),
            ingredients = listOf(
                BiText("1 tsp ceremonial matcha powder", "ملعقة صغيرة ماتشا تقليدية"),
                BiText("250 ml cold or warm water", "250 مل ماء بارد أو دافئ"),
                BiText("1 scoop L-citrulline or beetroot powder", "مغرفة سيترولين أو مسحوق شمندر"),
                BiText("1 small banana or 1 date", "موزة صغيرة أو تمرة"),
                BiText("Ice cubes (optional)", "مكعبات ثلج (اختياري)")
            ),
            steps = BiList(
                listOf(
                    "Sift the matcha into a bowl to avoid lumps.",
                    "Add a splash of warm water and whisk in a zigzag motion until frothy.",
                    "Stir in the beetroot or citrulline powder.",
                    "Pour in the remaining water and add ice if desired.",
                    "Blend in the banana or date for energy, then drink 30 minutes before training."
                ),
                listOf(
                    "صفِّ الماتشا في وعاء لتجنّب التكتلات.",
                    "أضف قليلاً من الماء الدافئ واخفق بحركة متعرجة حتى تصبح رغوية.",
                    "أضف مسحوق الشمندر أو السيترولين وحرّك.",
                    "صب باقي الماء وأضف الثلج إن أحببت.",
                    "اخلط الموزة أو التمرة للطاقة، واشرب قبل التمرين بـ 30 دقيقة."
                )
            )
        ),
        Recipe(
            id = "casein",
            tag = "SLEEP",
            time = BiText("T-22:30 · 5 min prep", "قبل النوم بـ 22:30 دقيقة · 5 دقائق تحضير"),
            prepMin = 5,
            kcal = 320,
            proteinG = 38,
            carbsG = 14,
            fatsG = 12,
            imageRes = R.drawable.img_recipe_casein_1795003131301,
            name = BiText("Micellar Casein Cacao", "كازين ميسيلار بالكاكاو"),
            benefit = BiText(
                "Provides a steady 6–7 hour drip of amino acids while you sleep to prevent overnight muscle breakdown, while cacao flavanols and cinnamon support circulation and overnight satiety.",
                "يوفر إمداداً بطيئاً ومستمراً بالأحماض الأمينية لمدة 6–7 ساعات أثناء النوم لمنع الهدم العضلي الليلي، مع مضادات أكسدة الكاكاو والقرفة التي تدعم الاستشفاء والشبع."
            ),
            nutrition = RecipeNutrition(BiText("1 shake (≈400 ml)", "مشروب واحد (≈400 مل)"), 4, 260, 8),
            basics = BiText(
                "Micellar casein digests slowly, supporting overnight amino supply. Cacao adds flavanols. Not a substitute for a full dinner if you are underfed.",
                "الكازين الميسيلار يُهضم ببطء، فيغذي العضلات بالأحماض الأمينية ليلاً. الكاكاو يضيف فلافانولات. لا يغني عن العشاء الكامل."
            ),
            ingredients = listOf(
                BiText("30 g micellar casein powder", "30 غ مسحوق كازين ميسيلار"),
                BiText("300 ml cold milk or unsweetened almond milk", "300 مل حليب بارد أو حليب لوز بدون سكر"),
                BiText("1 tbsp unsweetened cacao powder", "ملعقة كبيرة كاكاو غير محلى"),
                BiText("1 tbsp natural peanut butter", "ملعقة كبيرة زبدة فول سوداني طبيعية"),
                BiText("A pinch of cinnamon", "رشة قرفة")
            ),
            steps = BiList(
                listOf(
                    "Add the milk to a shaker or blender first.",
                    "Add the casein powder and cacao, then blend or shake for 30 seconds.",
                    "Stir in the peanut butter and cinnamon for a thicker texture.",
                    "Let it rest 2 minutes so the casein thickens slightly.",
                    "Drink 30 minutes before sleep."
                ),
                listOf(
                    "ضع الحليب أولاً في الشيكر أو الخلاط.",
                    "أضف الكازين والكاكاو، ثم اخلط أو رج لمدة 30 ثانية.",
                    "أضف زبدة الفول السوداني والقرفة لقوام أكثف.",
                    "اتركه دقيقتين ليتماسك الكازين قليلاً.",
                    "اشربه قبل النوم بـ 30 دقيقة."
                )
            )
        ),
        Recipe(
            id = "beef",
            tag = "MEAL #2",
            time = BiText("Midday · 25 min prep", "منتصف النهار · 25 دقيقة تحضير"),
            prepMin = 25,
            kcal = 580,
            proteinG = 52,
            carbsG = 55,
            fatsG = 16,
            imageRes = R.drawable.img_recipe_beef_1795003132671,
            name = BiText("Lean Beef & Sweet Potato", "لحم بقري قليل الدهن مع البطاطا الحلوة"),
            benefit = BiText(
                "Powers strength and red blood cell oxygen delivery with bioavailable heme iron, zinc, natural creatine and B12, paired with potassium-rich sweet potato for clean muscular fullness.",
                "يرفع القوة والأداء البدني ونقل الأكسجين للعضلات بفضل الحديد الهيمي والزنك والكرياتين الطبيعي وفيتامين B12، مع بطاطا حلوة غنية بالبوتاسيوم وفيتامين A لطاقة مستمرة."
            ),
            nutrition = RecipeNutrition(BiText("1 plate (≈450 g)", "طبق واحد (≈450 غ)"), 8, 480, 9),
            basics = BiText(
                "High in heme iron, zinc and B12. Sweet potato adds beta-carotene. Choose lean cuts; cook to medium for tenderness.",
                "غني بالحديد الهيمي والزنك وB12. البطاطا الحلوة تضيف بيتا كاروتين. اختر قطعاً قليلة الدهن واطهه متوسطاً ليبقى طرياً."
            ),
            ingredients = listOf(
                BiText("180 g lean beef sirloin", "180 غ شريحة لحم بقري قليلة الدهن"),
                BiText("200 g sweet potato, cubed", "200 غ بطاطا حلوة مكعبة"),
                BiText("1 cup green beans", "كوب فاصوليا خضراء"),
                BiText("1 tsp olive oil", "ملعقة صغيرة زيت زيتون"),
                BiText("Garlic, paprika, salt, pepper", "ثوم، بابريكا، ملح، فلفل")
            ),
            steps = BiList(
                listOf(
                    "Roast the sweet potato cubes at 200°C for 20 minutes with a drizzle of oil.",
                    "Season the beef with garlic, paprika, salt and pepper; rest 5 minutes.",
                    "Sear the beef in a hot pan 2–3 minutes per side for medium.",
                    "Steam the green beans for 4 minutes until tender-crisp.",
                    "Slice the beef against the grain and serve with the potatoes and beans."
                ),
                listOf(
                    "اخبز مكعبات البطاطا الحلوة على حرارة 200 درجة لمدة 20 دقيقة مع قليل من الزيت.",
                    "تبّل اللحم بالثوم والبابريكا والملح والفلفل، واتركه 5 دقائق.",
                    "اشوِ اللحم في مقلاة ساخنة 2–3 دقائق لكل جانب للاستواء المتوسط.",
                    "اطهُ الفاصوليا على البخار 4 دقائق حتى تصبح طرية مقرمشة.",
                    "قطّع اللحم عكس الألياف، وقدّمه مع البطاطا والفاصوليا."
                )
            )
        ),
        Recipe(
            id = "yogurt",
            tag = "SNACK",
            time = BiText("Mid-afternoon · 3 min prep", "منتصف بعد الظهر · 3 دقائق تحضير"),
            prepMin = 3,
            kcal = 260,
            proteinG = 24,
            carbsG = 28,
            fatsG = 6,
            imageRes = R.drawable.img_recipe_yogurt_1795003133030,
            name = BiText("Greek Yogurt & Berry Bowl", "وعاء الزبادي اليوناني والتوت"),
            benefit = BiText(
                "Delivers 24 g of fast & slow dairy protein in low calories to curb cravings, supports gut health with probiotics and chia fibre, and combats oxidative stress via berry polyphenols.",
                "يمنحك 24 غ بروتيناً بسعرات منخفضة لكبح الجوع والحفاظ على العضلات، ويدعم صحة الأمعاء بالبروبيوتيك وألياف الشيا، ويحارب الإجهاد التأكسدي بمضادات أكسدة التوت."
            ),
            nutrition = RecipeNutrition(BiText("1 bowl (≈290 g)", "وعاء واحد (≈290 غ)"), 5, 90, 14),
            basics = BiText(
                "Protein-dense and low in fat. Berries add anthocyanins; chia adds omega-3 ALA and fibre. Honey adds sugar, so use sparingly.",
                "كثيف البروتين وقليل الدهن. التوت يضيف أنثوسيانين، والشيا يضيف أوميغا 3 وألياف. العسل يضيف سكراً، فاستخدمه بقلة."
            ),
            ingredients = listOf(
                BiText("200 g plain Greek yogurt (0% fat)", "200 غ زبادي يوناني سادة (0% دهون)"),
                BiText("80 g mixed berries", "80 غ توت مشكّل"),
                BiText("1 tbsp chia seeds", "ملعقة كبيرة بذور الشيا"),
                BiText("1 tsp honey (optional)", "ملعقة صغيرة عسل (اختياري)"),
                BiText("A few crushed walnuts", "القليل من الجوز المهروس")
            ),
            steps = BiList(
                listOf(
                    "Spoon the Greek yogurt into a bowl.",
                    "Add the berries on top.",
                    "Sprinkle the chia seeds and walnuts for crunch.",
                    "Drizzle a little honey if you like.",
                    "Eat immediately or chill for 10 minutes to thicken the chia."
                ),
                listOf(
                    "ضع الزبادي اليوناني في وعاء.",
                    "ضع التوت فوقه.",
                    "رش بذور الشيا والجوز للقرمشة.",
                    "أضف قليلاً من العسل إن أحببت.",
                    "تناوله فوراً أو برّده 10 دقائق ليتماسك الشيا."
                )
            )
        )
    )

    private fun f(num: Int, catIdx: Int, enT: String, enB: String, arT: String, arB: String) =
        FoodFact(num, FactCategory.entries[catIdx], BiText(enT, arT), BiText(enB, arB))

    val facts: List<FoodFact> = listOf(
        f(1, 0, "Whey + Banana", "Fast whey with simple carbs speeds amino delivery and glycogen refill.", "واي + موز", "الواي السريع مع الكربوهيدرات البسيطة يسرّع وصول الأحماض الأمينية وتعويض الجلايكوجين."),
        f(2, 0, "Eggs + Whole-Grain Toast", "A complete protein with complex carbs supports post-workout muscle protein synthesis.", "بيض + توست حبوب كاملة", "بروتين كامل مع كربوهيدرات معقدة يدعم بناء البروتين العضلي بعد التمرين."),
        f(3, 0, "Chicken + Rice", "Leucine in chicken activates mTOR, the main switch for muscle building.", "دجاج + أرز", "الليوسين في الدجاج يفعّل mTOR، وهو المفتاح الرئيسي لبناء العضلات."),
        f(4, 0, "Greek Yogurt + Berries", "Casein in dairy releases amino acids slowly, ideal for overnight repair.", "زبادي يوناني + توت", "الكازين في الألبان يطلق الأحماض الأمينية ببطء، وهو مثالي لإصلاح العضلات ليلاً."),
        f(5, 0, "Lentils + Brown Rice", "Combining plant proteins completes the essential amino acid profile.", "عدس + أرز بني", "دمج البروتينات النباتية يكمل ملف الأحماض الأمينية الأساسية."),
        f(6, 0, "Creatine + Carbohydrate", "Insulin from carbs may increase creatine uptake into muscle.", "كرياتين + كربوهيدرات", "الإنسولين الناتج عن الكربوهيدرات قد يزيد امتصاص الكرياتين في العضلات."),
        f(7, 0, "Lean Beef + Sweet Potato", "Heme iron and beta-carotene support oxygen delivery and tissue repair.", "لحم بقري قليل الدهن + بطاطا حلوة", "الحديد الهيمي وبيتا كاروتين يدعمان نقل الأكسجين وإصلاح الأنسجة."),
        f(8, 0, "Salmon + Quinoa", "Omega-3 fats may help moderate inflammation after heavy sessions.", "سلمون + كينوا", "أحماض أوميغا 3 قد تساعد على تهدئة الالتهاب بعد الجلسات الثقيلة."),
        f(9, 0, "Tart Cherry + Protein", "Anthocyanins may reduce perceived muscle soreness after strength work.", "كرز حامض + بروتين", "الأنثوسيانين قد يخفف آلام العضلات بعد تمارين القوة."),
        f(10, 0, "Dates + Milk", "Fast sugar and milk protein replenish glycogen and amino acids together.", "تمر + حليب", "السكر السريع والبروتين في الحليب يعوضان الجلايكوجين والأحماض الأمينية معاً."),
        f(11, 0, "Oats + Whey", "Slow carbs keep blood glucose steady while protein feeds repair.", "شوفان + واي", "الكربوهيدرات البطيئة تحافظ على استقرار السكر في الدم بينما يغذي البروتين الإصلاح."),
        f(12, 0, "Tuna + Potatoes", "Potassium and protein support muscle contraction and fluid balance.", "تونا + بطاطس", "البوتاسيوم والبروتين يدعمان انقباض العضلات وتوازن السوائل."),
        f(13, 0, "Cottage Cheese + Pineapple", "Slow casein plus fresh pineapple enzymes ease digestion before bed.", "جبنة قريش + أناناس", "الكازين البطيء مع إنزيمات الأناناس الطازج يسهّلان الهضم قبل النوم."),
        f(14, 0, "Pumpkin Seeds + Chicken", "Magnesium in the seeds supports protein synthesis and nerve signalling.", "بذور اليقطين + دجاج", "المغنيسيوم في البذور يدعم بناء البروتين وإشارات الأعصاب."),
        f(15, 0, "Edamame + Brown Rice", "Plant protein with fibre gives steady energy for recovery meals.", "إدامامي + أرز بني", "بروتين نباتي مع الألياف يمنح طاقة ثابتة لوجبات الاستشفاء."),
        f(16, 0, "Chocolate Milk After Training", "A carb-to-protein ratio near 3:1 is commonly used for post-exercise refuelling.", "حليب بالكاكاو بعد التمرين", "نسبة كربوهيدرات إلى بروتين قرابة 3:1 تُستخدم عادة لإعادة التزود بعد التمرين."),
        f(17, 0, "Turkey + Spinach", "Iron and protein together support oxygen transport to working muscle.", "ديك رومي + سبانخ", "الحديد والبروتين معاً يدعمان نقل الأكسجين إلى العضلات العاملة."),
        f(18, 0, "Chickpeas + Tahini", "Plant protein and unsaturated fats combine for sustained repair.", "حمص + طحينة", "بروتين نباتي ودهون غير مشبعة يتكاملان لإصلاح مستمر."),
        f(19, 0, "Kefir + Oats", "Protein from kefir with oat fibre supports steady amino absorption.", "كفير + شوفان", "بروتين الكفير مع ألياف الشوفان يدعم امتصاصاً ثابتاً للأحماض الأمينية."),
        f(20, 0, "Sardines + Lemon", "Calcium, omega-3 and vitamin C together support bone and muscle health.", "سردين + ليمون", "الكالسيوم وأوميغا 3 وفيتامين C معاً يدعمون صحة العظام والعضلات."),
        f(21, 1, "Protein-First Meals", "Eating protein first raises satiety and helps preserve lean mass in a deficit.", "البروتين أولاً", "تناول البروتين أولاً يرفع الشبع ويحافظ على الكتلة العضلية أثناء العجز في السعرات."),
        f(22, 1, "Green Tea + Lemon", "Catechins in green tea may modestly support energy expenditure.", "شاي أخضر + ليمون", "الكاتيكين في الشاي الأخضر قد يدعم حرق الطاقة بشكل معتدل."),
        f(23, 1, "Apple + Almonds", "Fibre and fats slow digestion and reduce the urge to snack.", "تفاح + لوز", "الألياف والدهون تبطئ الهضم وتقلل الرغبة في تناول الوجبات الخفيفة."),
        f(24, 1, "Eggs + Spinach", "A high-volume, high-protein meal supports appetite control.", "بيض + سبانخ", "وجبة عالية الحجم والبروتين تدعم التحكم في الشهية."),
        f(25, 1, "Chili + Lean Protein", "Capsaicin may modestly increase thermogenesis for some people.", "فلفل حار + بروتين قليل الدهن", "الكابسيسين قد يزيد الحرارة المتولدة في الجسم بشكل معتدل لدى بعض الأشخاص."),
        f(26, 1, "Cucumber + Greek Yogurt", "A water-rich, protein-dense snack lowers calorie density.", "خيار + زبادي يوناني", "وجبة خفيفة غنية بالماء والبروتين تقلل كثافة السعرات."),
        f(27, 1, "Lentil Soup + Olive Oil", "Fibre and monounsaturated fat slow gastric emptying and extend fullness.", "شوربة عدس + زيت زيتون", "الألياف والدهون الأحادية تبطئ إفراغ المعدة وتطيل الشعور بالشبع."),
        f(28, 1, "Coffee Before Training", "Caffeine improves performance and lowers perceived effort in many studies.", "قهوة قبل التمرين", "الكافيين يحسّن الأداء ويخفف الإحساس بالجهد في دراسات كثيرة."),
        f(29, 1, "Broccoli + Chicken", "Low-calorie vegetables with lean protein deliver volume and fullness.", "بروكلي + دجاج", "خضار قليلة السعرات مع بروتين نحيف تمنح حجماً وشبعاً."),
        f(30, 1, "Oatmeal + Cinnamon", "Beta-glucan and cinnamon may help flatten post-meal glucose spikes.", "شوفان + قرفة", "بيتا غلوكان والقرفة قد يساعدان في تقليل ارتفاع السكر بعد الوجبة."),
        f(31, 1, "Vinegar With Starchy Meals", "Acetic acid may blunt the glucose rise after a carb-heavy meal.", "خل مع الوجبات النشوية", "حمض الخليك قد يخفف ارتفاع السكر بعد وجبة غنية بالكربوهيدرات."),
        f(32, 1, "Tomato + Olive Oil", "Lycopene is absorbed better when eaten with fat.", "طماطم + زيت زيتون", "الليكوبين يُمتص بشكل أفضل عندما يؤكل مع الدهون."),
        f(33, 1, "Berries + Yogurt", "A lower-sugar sweet option with protein and fibre to curb cravings.", "توت + زبادي", "حلوى أقل سكراً مع بروتين وألياف تكبح الرغبة في الحلويات."),
        f(34, 1, "Water Before Meals", "Drinking water before a meal may reduce how much you eat in some studies.", "ماء قبل الوجبات", "شرب الماء قبل الوجبة قد يقلل كمية الطعام في بعض الدراسات."),
        f(35, 1, "Cottage Cheese + Berries", "Slow-digesting casein keeps hunger lower between meals.", "جبنة قريش + توت", "الكازين بطيء الهضم يبقي الجوع أقل بين الوجبات."),
        f(36, 1, "Beans + Quinoa", "Combined fibre and protein improve meal satisfaction.", "فاصوليا + كينوا", "الألياف والبروتين معاً يحسنان الرضا بعد الوجبة."),
        f(37, 1, "Avocado + Egg", "Healthy fats increase satisfaction and reduce later snacking.", "أفوكادو + بيض", "الدهون الصحية ترفع الرضا وتقلل الوجبات الخفيفة لاحقاً."),
        f(38, 1, "Pear + Walnuts", "Fibre plus plant omega-3 gives slower, steadier energy.", "كمثرى + جوز", "الألياف مع أوميغا 3 النباتية تمنح طاقة أبطأ وأكثر ثباتاً."),
        f(39, 1, "Shrimp + Zucchini", "Lean protein with low-calorie vegetables builds a filling, light plate.", "جمبري + كوسا", "بروتين نحيف مع خضار قليلة السعرات يصنع طبقاً مشبعاً وخفيفاً."),
        f(40, 1, "Sleep + Protein at Dinner", "Good sleep supports appetite hormones; dinner protein supports overnight fullness.", "النوم + بروتين العشاء", "النوم الجيد يدعم هرمونات الشهية، والبروتين عند العشاء يدعم الشبع ليلاً."),
        f(41, 2, "Turmeric + Black Pepper", "Piperine can raise curcumin absorption by up to 2,000% in one study.", "كركم + فلفل أسود", "البيبيرين قد يرفع امتصاص الكركمين حتى 2000% في دراسة واحدة."),
        f(42, 2, "Spinach + Lemon", "Vitamin C converts non-heme iron into a more absorbable form.", "سبانخ + ليمون", "فيتامين C يحوّل الحديد غير الهيمي إلى شكل أسهل امتصاصاً."),
        f(43, 2, "Fermented Foods + Protein", "Fermented foods may support gut microbial diversity.", "أطعمة مخمّرة + بروتين", "الأطعمة المخمّرة قد تدعم تنوع البكتيريا النافعة في الأمعاء."),
        f(44, 2, "Ginger + Warm Water", "Gingerols may help ease gastric motility after meals.", "زنجبيل + ماء دافئ", "الجنجرول قد يساعد على تحسين حركة المعدة بعد الوجبات."),
        f(45, 2, "Oats + Chia or Flax", "Soluble fibre slows the glycaemic response and feeds good bacteria.", "شوفان + شيا أو كتان", "الألياف القابلة للذوبان تبطئ استجابة السكر وتغذي البكتيريا النافعة."),
        f(46, 2, "Yogurt + Honey", "Live cultures with a little honey make a gentle, digestible snack.", "زبادي + عسل", "الثقافات الحية مع القليل من العسل تصنع وجبة خفيفة لطيفة على المعدة."),
        f(47, 2, "Garlic + Onion", "Prebiotic fructans feed beneficial gut bacteria.", "ثوم + بصل", "الفركتانات البريبايوتيك تغذي البكتيريا النافعة في الأمعاء."),
        f(48, 2, "Red Meat + Vitamin C Foods", "Vitamin C improves absorption of iron from meat in the same meal.", "لحم أحمر + أطعمة غنية بفيتامين C", "فيتامين C يحسن امتصاص الحديد من اللحم في الوجبة نفسها."),
        f(49, 2, "Calcium + Vitamin D", "Vitamin D increases the intestinal absorption of dietary calcium.", "كالسيوم + فيتامين D", "فيتامين D يزيد امتصاص الكالسيوم من الأمعاء."),
        f(50, 2, "Salmon + Avocado", "Healthy fats help absorb fat-soluble vitamins A, D, E and K.", "سلمون + أفوكادو", "الدهون الصحية تساعد على امتصاص الفيتامينات A وD وE وK الذائبة في الدهون."),
        f(51, 2, "Carrots + Olive Oil", "Carotenoids in carrots are absorbed much better with a little fat.", "جزر + زيت زيتون", "الكاروتينات في الجزر تُمتص أفضل بكثير مع القليل من الدهون."),
        f(52, 2, "Kiwi After Protein", "Kiwi provides vitamin C and enzymes that may assist digestion.", "كيوي بعد البروتين", "الكيوي يوفر فيتامين C وإنزيمات قد تساعد على الهضم."),
        f(53, 2, "Peppermint Tea After Meals", "Peppermint may relax gut muscles and ease bloating for some people.", "شاي النعناع بعد الوجبات", "النعناع قد يرخي عضلات الأمعاء ويخفف الانتفاخ لدى بعض الناس."),
        f(54, 2, "Slightly Green Banana", "Resistant starch feeds colon bacteria that make short-chain fatty acids.", "موزة شبه خضراء", "النشا المقاوم يغذي بكتيريا القولون التي تنتج أحماضاً دهنية قصيرة السلسلة."),
        f(55, 2, "Beans + Cumin", "Certain spices may ease gas and bloating for people who eat legumes.", "فاصوليا + كمون", "بعض البهارات قد تخفف الغازات والانتفاخ لمن يأكلون البقوليات."),
        f(56, 2, "Psyllium + Water", "Viscous fibre supports regularity when fluid intake is adequate.", "قشر السيليوم + ماء", "الألياف اللزجة تدعم انتظام الأمعاء مع شرب كمية كافية من الماء."),
        f(57, 2, "Kefir + Oats Pairing", "A probiotic and prebiotic pairing that supports a diverse gut environment.", "كفير + شوفان كتزاوج", "ثنائي بروبيوتيك وبريبايوتيك يدعم بيئة أمعاء متنوعة."),
        f(58, 2, "Eggs + Cooked Vegetables", "Cooking softens fibre, which many people tolerate better than raw vegetables.", "بيض + خضار مطبوخة", "الطهي يلين الألياف، وكثيرون يتحملونها أفضل من الخضار النيئة."),
        f(59, 2, "Fresh Pineapple + Meat", "Bromelain may assist protein breakdown during digestion.", "أناناس طازج + لحم", "البروميلين قد يساعد في تفكيك البروتين أثناء الهضم."),
        f(60, 2, "Cinnamon + Apple", "Polyphenols in apples and cinnamon may support a healthy gut microbiome.", "قرفة + تفاح", "البوليفينولات في التفاح والقرفة قد تدعم ميكروبيوم أمعاء صحياً."),
        f(61, 3, "Omega-3 + Vitamin D", "Both support normal musculoskeletal function and inflammation balance.", "أوميغا 3 + فيتامين D", "كلاهما يدعم وظيفة الجهاز العضلي الهيكلي الطبيعية وتوازن الالتهاب."),
        f(62, 3, "Vitamin C + Collagen Peptides", "Vitamin C is a required cofactor for collagen synthesis.", "فيتامين C + ببتيدات الكولاجين", "فيتامين C عامل مساعد ضروري لتكوين الكولاجين."),
        f(63, 3, "Tart Cherry Before Sleep", "Anthocyanins may support recovery and sleep quality after hard training.", "كرز حامض قبل النوم", "الأنثوسيانين قد يدعم الاستشفاء وجودة النوم بعد التمرين الشاق."),
        f(64, 3, "Bone Broth + Protein", "Glycine and proline are building blocks of connective tissue.", "مرق العظام + بروتين", "الجلايسين والبرولين لبنتان أساسيتان في الأنسجة الضامة."),
        f(65, 3, "Turmeric + Healthy Fat", "Curcumin may support joint comfort, and fat improves its absorption.", "كركم + دهون صحية", "الكركمين قد يدعم راحة المفاصل، والدهون تحسن امتصاصه."),
        f(66, 3, "Magnesium-Rich Foods", "Magnesium supports normal muscle relaxation and nerve function.", "أطعمة غنية بالمغنيسيوم", "المغنيسيوم يدعم استرخاء العضلات الطبيعي ووظيفة الأعصاب."),
        f(67, 3, "Ginger With Meals", "Ginger may help reduce exercise-related muscle soreness.", "زنجبيل مع الوجبات", "الزنجبيل قد يساعد على تخفيف آلام العضلات بعد التمرين."),
        f(68, 3, "Pineapple After a Run", "Bromelain and vitamin C support tissue recovery after endurance work.", "أناناس بعد الجري", "البروميلين وفيتامين C يدعمان استشفاء الأنسجة بعد تمارين التحمل."),
        f(69, 3, "Zinc + Protein", "Zinc is required for enzymes involved in tissue repair and immunity.", "زنك + بروتين", "الزنك ضروري للإنزيمات المشاركة في إصلاح الأنسجة والمناعة."),
        f(70, 3, "Vitamin K2 + Vitamin D", "Together they support healthy bone mineral metabolism.", "فيتامين K2 + فيتامين D", "معاً يدعمان استقلاب معادن العظام بشكل صحي."),
        f(71, 3, "Strawberries + Protein", "Vitamin C in strawberries supports collagen alongside dietary protein.", "فراولة + بروتين", "فيتامين C في الفراولة يدعم الكولاجين مع البروتين الغذائي."),
        f(72, 3, "Walnuts + Oily Fish", "Omega-3 fats may help reduce exercise-induced inflammation.", "جوز + أسماك دهنية", "أوميغا 3 قد تساعد على تقليل الالتهاب الناتج عن التمرين."),
        f(73, 3, "Potassium-Rich Foods", "Potassium supports fluid balance and normal muscle contraction.", "أطعمة غنية بالبوتاسيوم", "البوتاسيوم يدعم توازن السوائل وانقباض العضلات الطبيعي."),
        f(74, 3, "Electrolytes After Heavy Sweat", "Sodium and water replace what sweat removes during long sessions.", "أملاح الكهارل بعد التعرق الشديد", "الصوديوم والماء يعوضان ما يفقده العرق في الجلسات الطويلة."),
        f(75, 3, "Dark Leafy Greens + Olive Oil", "Vitamin K and magnesium from greens absorb well with healthy fat.", "خضار ورقية داكنة + زيت زيتون", "فيتامين K والمغنيسيوم من الخضار يُمتصان جيداً مع الدهون الصحية."),
        f(76, 3, "Egg Yolks + Vitamin D Sources", "Egg yolks contribute vitamin D, which supports calcium use in bone.", "صفار البيض + مصادر فيتامين D", "صفار البيض يوفر فيتامين D الذي يدعم استخدام الكالسيوم في العظم."),
        f(77, 3, "Cacao + Recovery Meals", "Cocoa flavanols may support healthy circulation to recovering tissue.", "كاكاو + وجبات الاستشفاء", "الفلافانولات في الكاكاو قد تدعم الدورة الدموية الصحية للأنسجة المتعافية."),
        f(78, 3, "Coconut Water in Long Sessions", "Natural electrolytes help maintain hydration during extended training.", "ماء جوز الهند في الجلسات الطويلة", "الأملاح الطبيعية تساعد على الحفاظ على الترطيب خلال التمرين الممتد."),
        f(79, 3, "Casein Before Bed", "A slow protein source supports muscle and connective tissue repair overnight.", "كازين قبل النوم", "مصدر بروتين بطيء يدعم إصلاح العضلات والأنسجة الضامة ليلاً."),
        f(80, 3, "Anti-Inflammatory Spice Blend", "Cumin, ginger and turmeric add polyphenols that support recovery.", "خلطة البهارات المضادة للالتهاب", "الكمون والزنجبيل والكركم تضيف بوليفينولات تدعم الاستشفاء."),
        f(81, 4, "Blueberries + Dark Chocolate", "Flavonoids are linked to better attention and memory in several studies.", "توت أزرق + شوكولاتة داكنة", "الفلافونويدات مرتبطة بتحسن الانتباه والذاكرة في دراسات عدة."),
        f(82, 4, "Eggs + Choline", "Choline is a precursor for acetylcholine, a neurotransmitter linked to memory.", "بيض + كولين", "الكولين مادة أولية للأسيتيل كولين، وهو ناقل عصبي مرتبط بالذاكرة."),
        f(83, 4, "Walnuts + Omega-3", "DHA supports the structure of neuronal membranes.", "جوز + أوميغا 3", "حمض DHA يدعم بنية أغشية الخلايا العصبية."),
        f(84, 4, "Matcha + L-Theanine", "L-theanine with caffeine is linked to calm, focused alertness.", "ماتشا + ثيانين", "الثيانين مع الكافيين مرتبط بيقظة هادئة ومركزة."),
        f(85, 4, "Oats + Banana", "Steady glucose release supports sustained attention through the morning.", "شوفان + موز", "إطلاق سكر ثابت يدعم الانتباه المستمر خلال الصباح."),
        f(86, 4, "Pumpkin Seeds + Zinc", "Zinc plays a role in neurotransmission and synaptic signalling.", "بذور اليقطين + زنك", "الزنك يلعب دوراً في نقل الإشارات العصبية بين الخلايا."),
        f(87, 4, "Salmon + B12 Foods", "Vitamin B12 is essential for nerve function and myelin formation.", "سلمون + أطعمة غنية بـ B12", "فيتامين B12 ضروري لوظيفة الأعصاب وتكوين غمد الميالين."),
        f(88, 4, "Coffee + Water", "Caffeine improves alertness; water prevents fatigue-related lapses.", "قهوة + ماء", "الكافيين يحسن اليقظة، والماء يمنع الشرود المرتبط بالتعب."),
        f(89, 4, "Leafy Greens + Folate", "Folate supports healthy cognitive function and red blood cell production.", "خضار ورقية + حمض الفوليك", "حمض الفوليك يدعم الوظائف الإدراكية الصحية وإنتاج كريات الدم الحمراء."),
        f(90, 4, "Beetroot + Nitrates", "Dietary nitrate may improve blood flow, including to the brain, in some studies.", "شمندر + نترات", "النترات الغذائية قد تحسن تدفق الدم، بما في ذلك إلى الدماغ، في بعض الدراسات."),
        f(91, 4, "Fatty Fish + Vitamin D", "Vitamin D receptors in brain tissue are linked to mood regulation.", "أسماك دهنية + فيتامين D", "مستقبلات فيتامين D في أنسجة الدماغ مرتبطة بتنظيم المزاج."),
        f(92, 4, "Greek Yogurt + Berries", "Protein and polyphenols together help keep energy and mood steady.", "زبادي يوناني + توت", "البروتين والبوليفينولات معاً تساعدان على ثبات الطاقة والمزاج."),
        f(93, 4, "Peanut Butter on Whole-Grain Toast", "Protein, fat and fibre give slow, steady energy.", "زبدة فول سوداني على توست حبوب كاملة", "البروتين والدهون والألياف تمنح طاقة بطيئة ومستقرة."),
        f(94, 4, "Iodized Salt + Seafood", "Iodine supports thyroid hormones linked to brain development and alertness.", "ملح يوديد + مأكولات بحرية", "اليود يدعم هرمونات الغدة الدرقية المرتبطة بنمو الدماغ واليقظة."),
        f(95, 4, "Dark Chocolate + Nuts", "Polyphenols and healthy fats support a balanced, focused state.", "شوكولاتة داكنة + مكسرات", "البوليفينولات والدهون الصحية تدعم حالة متوازنة ومركزة."),
        f(96, 4, "Green Tea + Almonds", "Vitamin E from almonds and catechins from tea both act as antioxidants.", "شاي أخضر + لوز", "فيتامين E من اللوز والكاتيكين من الشاي كلاهما مضاد للأكسدة."),
        f(97, 4, "Rosemary + Roasted Meat", "Carnosic acid in rosemary is an antioxidant that helps protect fats during cooking.", "إكليل الجبل + لحم مشوي", "حمض الكارنوسيك في إكليل الجبل مضاد للأكسدة ويحمي الدهون أثناء الطهي."),
        f(98, 4, "Hydration for Focus", "Mild dehydration can impair attention and mood, so steady fluid intake matters.", "الترطيب من أجل التركيز", "الجفاف الخفيف قد يضعف الانتباه والمزاج، لذا فالسوائل المنتظمة مهمة."),
        f(99, 4, "Pomegranate + Yogurt", "Pomegranate polyphenols pair well with protein for sustained cognitive energy.", "رمان + زبادي", "بوليفينولات الرمان تتكامل مع البروتين لطاقة ذهنية مستمرة."),
        f(100, 4, "Magnesium Foods Before Sleep", "Magnesium supports sleep quality, which is important for memory consolidation.", "أطعمة المغنيسيوم قبل النوم", "المغنيسيوم يدعم جودة النوم، وهي مهمة لترسيخ الذاكرة.")
    )

    val gear: List<GearItem> = listOf(
        GearItem(0, BiText("Competition Gymnastic Rings", "حلقات جمباز للمنافسة"), BiText("Rings", "حلقات"), 59,
            BiList(listOf("Wood, 28 mm grip", "Adjustable straps up to 3 m", "Load rated for 150 kg"), listOf("خشب، قبضة 28 مم", "أحزمة قابلة للتعديل حتى 3 م", "تحمل حتى 150 كغ"))),
        GearItem(1, BiText("Steel Parallettes Pair", "زوج قضبان متوازية فولاذية"), BiText("Parallettes", "متوازيات"), 45,
            BiList(listOf("Non-slip rubber base", "Height 20 cm", "Powder-coated steel"), listOf("قاعدة مطاطية مانعة للانزلاق", "ارتفاع 20 سم", "فولاذ مطلي"))),
        GearItem(2, BiText("Resistance Band Set (5 Levels)", "مجموعة أحزمة مقاومة (5 مستويات)"), BiText("Bands", "أحزمة"), 29,
            BiList(listOf("Latex-free fabric loops", "5 resistance levels", "Door anchor and carry bag"), listOf("حلقات قماشية خالية من اللاتكس", "5 مستويات مقاومة", "مثبت للباب وحقيبة حمل"))),
        GearItem(3, BiText("Doorway Pull-Up Bar", "عارضة عقلة للباب"), BiText("Bars", "عارضات"), 39,
            BiList(listOf("No-screw door mounting", "Holds up to 150 kg", "Foam grips"), listOf("تركيب على الباب بدون براغي", "تتحمل حتى 150 كغ", "مقابض إسفنجية"))),
        GearItem(4, BiText("Weighted Vest 10 kg", "سترة أثقال 10 كغ"), BiText("Loading", "أثقال"), 55,
            BiList(listOf("Adjustable 2 kg steel plates", "Breathable mesh", "Fits sizes S to XL"), listOf("ألواح فولاذية 2 كغ قابلة للتعديل", "شبك يسمح بالتهوية", "مقاسات S إلى XL"))),
        GearItem(5, BiText("Lacrosse Recovery Ball Pair", "زوج كرات استشفاء"), BiText("Recovery", "استشفاء"), 19,
            BiList(listOf("Dense rubber", "Targets glutes and pecs", "Carry pouch included"), listOf("مطاط كثيف", "تستهدف الأرداف والصدر", "تأتي مع حقيبة حمل"))),
        GearItem(6, BiText("Textured Foam Roller", "أسطوانة فوم للاستشفاء"), BiText("Recovery", "استشفاء"), 24,
            BiList(listOf("High-density EVA foam", "Textured surface", "33 cm length"), listOf("فوم EVA عالي الكثافة", "سطح مموج", "طول 33 سم"))),
        GearItem(7, BiText("Grip Strengthener Set", "مجموعة مقوّيات القبضة"), BiText("Grip", "القبضة"), 17,
            BiList(listOf("Three resistance levels", "Ergonomic handle", "Progress tracking chart"), listOf("ثلاثة مستويات مقاومة", "مقبض مريح", "جدول لتتبع التقدم")))
    )
}
