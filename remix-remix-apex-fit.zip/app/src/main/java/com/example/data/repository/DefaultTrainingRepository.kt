package com.example.data.repository

import com.example.data.ExerciseData
import com.example.data.MuscleAnchor
import com.example.data.PoseFrame
import com.example.domain.repository.TrainingRepository
import com.example.model.Exercise
import com.example.model.PoseType
import com.example.model.TrainingProgram
import com.example.model.WorkoutPlan

class DefaultTrainingRepository : TrainingRepository {
    override fun getPrograms(): List<TrainingProgram> = ExerciseData.programs
    override fun getWorkouts(): List<WorkoutPlan> = ExerciseData.workouts
    override fun getWorkoutById(id: String): WorkoutPlan? = ExerciseData.workoutsById[id]
    override fun getExercises(): List<Exercise> = ExerciseData.exercises
    override fun getExerciseById(id: String): Exercise? = ExerciseData.exercisesById[id]
    override fun getPoseFrames(pose: PoseType): List<PoseFrame> =
        ExerciseData.poseFrames[pose] ?: ExerciseData.poseFrames.getValue(PoseType.PUSHUP)
    override fun getMuscleAnchors(pose: PoseType): List<MuscleAnchor> =
        ExerciseData.muscleAnchors[pose].orEmpty()
}
