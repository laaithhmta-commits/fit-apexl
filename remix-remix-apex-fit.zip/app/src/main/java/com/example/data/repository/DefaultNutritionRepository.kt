package com.example.data.repository

import com.example.data.NutritionAcademyData
import com.example.data.NutritionData
import com.example.domain.repository.NutritionRepository
import com.example.model.FoodFact
import com.example.model.GearItem
import com.example.model.NutrientGuideItem
import com.example.model.Recipe

class DefaultNutritionRepository : NutritionRepository {
    override fun getRecipes(): List<Recipe> = NutritionData.recipes
    override fun getRecipeAt(index: Int): Recipe? = NutritionData.recipes.getOrNull(index)
    override fun getFoodFacts(): List<FoodFact> = NutritionData.facts
    override fun getNutrientGuides(): List<NutrientGuideItem> = NutritionAcademyData.nutrients
    override fun getGearCatalog(): List<GearItem> = NutritionData.gear
    override fun getGearItemAt(index: Int): GearItem? = NutritionData.gear.getOrNull(index)
}
