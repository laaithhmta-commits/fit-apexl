package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.repository.UserProgressRepository
import com.example.model.ApexUiState
import com.example.model.AppLanguage
import com.example.model.BiText
import com.example.model.ChatMessage
import com.example.model.Equipment
import com.example.model.LoggedMacros
import com.example.model.PsychState
import com.example.model.RegimenLevel
import com.example.model.TensionZone
import com.example.model.UserRegimen
import com.example.model.WorkoutLogEntry
import com.example.model.ZoneStatus
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import java.io.IOException

private val Context.apexDataStore: DataStore<Preferences> by preferencesDataStore(name = "apex_fit_prefs")

class PreferencesRepository(private val context: Context) : UserProgressRepository {

    private object Keys {
        val LANG = stringPreferencesKey("lang")
        val PSYCH = stringPreferencesKey("psych")
        val SLEEP = floatPreferencesKey("sleep")
        val HRV = intPreferencesKey("hrv")
        val RHR = intPreferencesKey("rhr")
        val ZONE_CHEST = stringPreferencesKey("zone_chest")
        val ZONE_HAMS = stringPreferencesKey("zone_hams")
        val ZONE_LOWER = stringPreferencesKey("zone_lower")
        val EQUIP = stringPreferencesKey("equip")
        val SWAPPED = booleanPreferencesKey("swapped")
        val REGIMEN_LEVEL = stringPreferencesKey("regimen_level")
        val REGIMEN_WID = stringPreferencesKey("regimen_wid")
        val STREAK = stringPreferencesKey("streak")
        val KCAL = intPreferencesKey("kcal")
        val PROTEIN = intPreferencesKey("protein")
        val CARBS = intPreferencesKey("carbs")
        val FATS = intPreferencesKey("fats")
        val WATER = intPreferencesKey("water")
        val CART = stringPreferencesKey("cart")
        val VOICE = booleanPreferencesKey("voice")
        val WORKOUT_HISTORY = stringPreferencesKey("workout_history")
        val CHAT_HISTORY = stringPreferencesKey("chat_history")
    }

    override suspend fun loadInitialState(
        recalcFn: (PsychState, Float, Int, Int, Map<TensionZone, ZoneStatus>) -> Int
    ): ApexUiState {
        val prefs = context.apexDataStore.data
            .catch { err ->
                if (err is IOException) emit(emptyPreferences()) else throw err
            }
            .first()

        val lang = AppLanguage.fromCode(prefs[Keys.LANG] ?: "ar")
        val psych = PsychState.entries.find { it.key == prefs[Keys.PSYCH] } ?: PsychState.FOCUSED
        val sleep = prefs[Keys.SLEEP] ?: 7.75f
        val hrv = prefs[Keys.HRV] ?: 62
        val rhr = prefs[Keys.RHR] ?: 48
        val zones = mapOf(
            TensionZone.CHEST to (ZoneStatus.entries.find { it.key == prefs[Keys.ZONE_CHEST] } ?: ZoneStatus.FRESH),
            TensionZone.HAMS to (ZoneStatus.entries.find { it.key == prefs[Keys.ZONE_HAMS] } ?: ZoneStatus.MILD_SORENESS),
            TensionZone.LOWER to (ZoneStatus.entries.find { it.key == prefs[Keys.ZONE_LOWER] } ?: ZoneStatus.READY)
        )
        val equipStr = prefs[Keys.EQUIP]
        val equip = if (equipStr == null) {
            setOf(Equipment.BAR, Equipment.TOWEL)
        } else if (equipStr.isBlank()) {
            emptySet()
        } else {
            equipStr.split(",").mapNotNull { id -> Equipment.entries.find { it.id == id } }.toSet()
        }
        val swapped = prefs[Keys.SWAPPED] ?: false
        val streakStr = prefs[Keys.STREAK]
        val streak = if (streakStr != null && streakStr.split(",").size == 7) {
            streakStr.split(",").map { it == "1" }
        } else {
            listOf(true, true, true, true, true, false, false)
        }
        val cartStr = prefs[Keys.CART]
        val cart = if (cartStr.isNullOrBlank()) emptyList() else cartStr.split(",").mapNotNull { it.toIntOrNull() }
        val macros = LoggedMacros(
            kcal = prefs[Keys.KCAL] ?: 0,
            proteinG = prefs[Keys.PROTEIN] ?: 0,
            carbsG = prefs[Keys.CARBS] ?: 0,
            fatsG = prefs[Keys.FATS] ?: 0
        )
        val water = prefs[Keys.WATER] ?: 3200
        val voice = prefs[Keys.VOICE] ?: false
        val recovery = recalcFn(psych, sleep, hrv, rhr, zones)

        val regLevelKey = prefs[Keys.REGIMEN_LEVEL]
        val regWid = prefs[Keys.REGIMEN_WID]
        val regimen = if (regLevelKey != null && regWid != null && ExerciseData.workoutsById.containsKey(regWid)) {
            val level = RegimenLevel.entries.find { it.key == regLevelKey } ?: RegimenLevel.MAINTAIN
            buildRegimenNote(level, regWid, recovery, psych, equip)
        } else null

        val history = decodeWorkoutHistory(prefs[Keys.WORKOUT_HISTORY])
        val savedChat = decodeChatHistory(prefs[Keys.CHAT_HISTORY])

        return ApexUiState(
            language = lang,
            psych = psych,
            sleepHours = sleep,
            hrvMs = hrv,
            rhrBpm = rhr,
            recoveryPercent = recovery,
            zones = zones,
            ownedEquipment = equip,
            swappedShoulderProtocol = swapped,
            regimen = regimen,
            streakDays = streak,
            loggedMacros = macros,
            waterMl = water,
            workoutHistory = history,
            cartIndices = cart,
            voiceEnabled = voice,
            chatMessages = savedChat.ifEmpty { ApexUiState.defaultChat() }
        )
    }

    override suspend fun saveState(state: ApexUiState) {
        context.apexDataStore.edit { prefs ->
            prefs[Keys.LANG] = state.language.code
            prefs[Keys.PSYCH] = state.psych.key
            prefs[Keys.SLEEP] = state.sleepHours
            prefs[Keys.HRV] = state.hrvMs
            prefs[Keys.RHR] = state.rhrBpm
            prefs[Keys.ZONE_CHEST] = (state.zones[TensionZone.CHEST] ?: ZoneStatus.FRESH).key
            prefs[Keys.ZONE_HAMS] = (state.zones[TensionZone.HAMS] ?: ZoneStatus.MILD_SORENESS).key
            prefs[Keys.ZONE_LOWER] = (state.zones[TensionZone.LOWER] ?: ZoneStatus.READY).key
            prefs[Keys.EQUIP] = state.ownedEquipment.joinToString(",") { it.id }
            prefs[Keys.SWAPPED] = state.swappedShoulderProtocol
            if (state.regimen != null) {
                prefs[Keys.REGIMEN_LEVEL] = state.regimen.level.key
                prefs[Keys.REGIMEN_WID] = state.regimen.workoutId
            }
            prefs[Keys.STREAK] = state.streakDays.joinToString(",") { if (it) "1" else "0" }
            prefs[Keys.KCAL] = state.loggedMacros.kcal
            prefs[Keys.PROTEIN] = state.loggedMacros.proteinG
            prefs[Keys.CARBS] = state.loggedMacros.carbsG
            prefs[Keys.FATS] = state.loggedMacros.fatsG
            prefs[Keys.WATER] = state.waterMl
            prefs[Keys.CART] = state.cartIndices.joinToString(",")
            prefs[Keys.VOICE] = state.voiceEnabled
            prefs[Keys.WORKOUT_HISTORY] = encodeWorkoutHistory(state.workoutHistory.take(30))
            prefs[Keys.CHAT_HISTORY] = encodeChatHistory(state.chatMessages.takeLast(40))
        }
    }

    companion object {
        private const val REC_SEP = "\u001E"
        private const val FLD_SEP = "\u001F"

        private fun sanitize(input: String): String =
            input.replace(REC_SEP, " ").replace(FLD_SEP, " ")

        fun encodeWorkoutHistory(items: List<WorkoutLogEntry>): String {
            return items.joinToString(REC_SEP) { entry ->
                listOf(
                    sanitize(entry.id),
                    sanitize(entry.workoutId),
                    sanitize(entry.title.en),
                    sanitize(entry.title.ar),
                    entry.kcal.toString(),
                    entry.setsCompleted.toString(),
                    entry.completedAtMillis.toString()
                ).joinToString(FLD_SEP)
            }
        }

        fun decodeWorkoutHistory(raw: String?): List<WorkoutLogEntry> {
            if (raw.isNullOrBlank()) return emptyList()
            return raw.split(REC_SEP).mapNotNull { line ->
                val parts = line.split(FLD_SEP)
                if (parts.size < 7) return@mapNotNull null
                val kcal = parts[4].toIntOrNull() ?: return@mapNotNull null
                val sets = parts[5].toIntOrNull() ?: return@mapNotNull null
                val ts = parts[6].toLongOrNull() ?: return@mapNotNull null
                WorkoutLogEntry(
                    id = parts[0],
                    workoutId = parts[1],
                    title = BiText(en = parts[2], ar = parts[3]),
                    kcal = kcal,
                    setsCompleted = sets,
                    completedAtMillis = ts
                )
            }
        }

        fun encodeChatHistory(items: List<ChatMessage>): String {
            return items.joinToString(REC_SEP) { msg ->
                listOf(
                    sanitize(msg.id),
                    if (msg.isUser) "1" else "0",
                    if (msg.isSwapCard) "1" else "0",
                    sanitize(msg.text?.en.orEmpty()),
                    sanitize(msg.text?.ar.orEmpty())
                ).joinToString(FLD_SEP)
            }
        }

        fun decodeChatHistory(raw: String?): List<ChatMessage> {
            if (raw.isNullOrBlank()) return emptyList()
            return raw.split(REC_SEP).mapNotNull { line ->
                val parts = line.split(FLD_SEP)
                if (parts.size < 5) return@mapNotNull null
                val en = parts[3]
                val ar = parts[4]
                val text = if (en.isEmpty() && ar.isEmpty()) null else BiText(en = en, ar = ar)
                ChatMessage(
                    id = parts[0],
                    isUser = parts[1] == "1",
                    text = text,
                    isSwapCard = parts[2] == "1"
                )
            }
        }

        fun buildRegimenNote(
            level: RegimenLevel,
            wid: String,
            recovery: Int,
            psych: PsychState,
            equip: Set<Equipment>
        ): UserRegimen {
            val wo = ExerciseData.workoutsById[wid] ?: ExerciseData.workouts.first()
            val eqEn = if (equip.isEmpty()) StringsData.equipmentName(Equipment.NONE, AppLanguage.EN)
            else equip.joinToString(", ") { StringsData.equipmentName(it, AppLanguage.EN) }
            val eqAr = if (equip.isEmpty()) StringsData.equipmentName(Equipment.NONE, AppLanguage.AR)
            else equip.joinToString("، ") { StringsData.equipmentName(it, AppLanguage.AR) }

            val enNote = "${level.key} day · ${wo.title.en}. Recovery $recovery% · ${StringsData.psychName(psych, AppLanguage.EN)}. Equipment: $eqEn."
            val arNote = "يوم ${StringsData.regimenLevelName(level, AppLanguage.AR)} · ${wo.title.ar}. الاستشفاء $recovery% · ${StringsData.psychName(psych, AppLanguage.AR)}. المعدات: $eqAr."
            return UserRegimen(level, wid, BiText(enNote, arNote))
        }
    }
}
