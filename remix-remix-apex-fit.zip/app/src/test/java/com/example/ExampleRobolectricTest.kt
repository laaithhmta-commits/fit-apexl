package com.example

import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `application initializes di container and app name`() {
        val app = ApplicationProvider.getApplicationContext<ApexFitApplication>()
        val appName = app.getString(R.string.app_name)
        assertEquals("Apex Fit", appName)
        assertNotNull(app.container.trainingRepository)
        assertNotNull(app.container.nutritionRepository)
        assertNotNull(app.container.userProgressRepository)
        assertEquals(35, app.container.trainingRepository.getExercises().size)
    }
}
