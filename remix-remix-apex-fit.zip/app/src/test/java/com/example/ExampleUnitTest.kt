package com.example

import com.example.data.ExerciseData
import com.example.data.NutritionAcademyData
import com.example.data.NutritionData
import com.example.data.PreferencesRepository
import com.example.data.repository.DefaultTrainingRepository
import com.example.domain.usecase.CoachEngineUseCase
import com.example.domain.usecase.ComputeRecoveryUseCase
import com.example.domain.usecase.GenerateRegimenUseCase
import com.example.domain.usecase.ResolveExerciseEquipmentUseCase
import com.example.model.ApexUiState
import com.example.model.AppLanguage
import com.example.model.BiText
import com.example.model.ChatMessage
import com.example.model.Equipment
import com.example.model.PsychState
import com.example.model.RegimenLevel
import com.example.model.TensionZone
import com.example.model.WorkoutLogEntry
import com.example.model.ZoneStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun default_language_is_arabic() {
        val state = ApexUiState()
        assertEquals(AppLanguage.AR, state.language)
    }

    @Test
    fun all_100_food_facts_and_5_recipes_with_benefits_exist_bilingually() {
        assertEquals(100, NutritionData.facts.size)
        assertEquals(5, NutritionData.recipes.size)
        assertEquals(8, NutritionData.gear.size)
        assertTrue(NutritionData.facts.all { it.title.ar.isNotBlank() && it.title.en.isNotBlank() })
        assertTrue(
            NutritionData.recipes.all {
                it.name.ar.isNotBlank() && it.benefit.ar.isNotBlank() && it.benefit.en.isNotBlank() && it.steps.ar.isNotEmpty()
            }
        )
    }

    @Test
    fun nutrition_academy_covers_macros_vitamins_and_minerals_bilingually() {
        assertEquals(17, NutritionAcademyData.nutrients.size)
        assertTrue(
            NutritionAcademyData.nutrients.all {
                it.name.ar.isNotBlank() && it.role.ar.isNotBlank() && it.foodSources.ar.isNotBlank() && it.dailyTarget.ar.isNotBlank()
            }
        )
    }

    @Test
    fun all_35_exercises_and_9_workouts_exist_bilingually() {
        assertEquals(35, ExerciseData.exercises.size)
        assertEquals(9, ExerciseData.workouts.size)
        assertEquals(4, ExerciseData.programs.size)
        assertTrue(ExerciseData.exercises.all { it.name.ar.isNotBlank() && it.steps.ar.size == 3 })
    }

    @Test
    fun domain_recovery_and_regimen_use_cases_work_accurately() {
        val trainingRepo = DefaultTrainingRepository()
        val computeRecovery = ComputeRecoveryUseCase()
        val generateRegimen = GenerateRegimenUseCase(trainingRepo)

        val peakRecovery = computeRecovery(
            psych = PsychState.PEAK,
            sleepHours = 8.5f,
            hrvMs = 80,
            rhrBpm = 45,
            zones = mapOf(
                TensionZone.CHEST to ZoneStatus.FRESH,
                TensionZone.HAMS to ZoneStatus.FRESH,
                TensionZone.LOWER to ZoneStatus.FRESH
            )
        )
        assertTrue(peakRecovery >= 85)
        val buildRegimen = generateRegimen(peakRecovery, PsychState.PEAK, setOf(Equipment.BAR))
        assertEquals(RegimenLevel.BUILD, buildRegimen.level)
        assertEquals("planche", buildRegimen.workoutId)

        val lowRecovery = computeRecovery(
            psych = PsychState.DRAINED,
            sleepHours = 4.5f,
            hrvMs = 35,
            rhrBpm = 66,
            zones = mapOf(
                TensionZone.CHEST to ZoneStatus.SORE,
                TensionZone.HAMS to ZoneStatus.SORE,
                TensionZone.LOWER to ZoneStatus.SORE
            )
        )
        assertTrue(lowRecovery < 60)
        val deloadRegimen = generateRegimen(lowRecovery, PsychState.DRAINED, emptySet())
        assertEquals(RegimenLevel.DELOAD, deloadRegimen.level)
        assertEquals("mob1", deloadRegimen.workoutId)
    }

    @Test
    fun resolve_exercise_equipment_and_coach_use_cases_work() {
        val trainingRepo = DefaultTrainingRepository()
        val resolveUseCase = ResolveExerciseEquipmentUseCase(trainingRepo)
        val swapped = resolveUseCase.resolveExercise(
            exerciseId = "wall-hspu",
            ownedEquipment = emptySet(),
            swappedShoulderProtocol = true
        )
        assertEquals("deficit-pike", swapped.id)

        val coach = CoachEngineUseCase()
        val reply = coach("شعرت بألم في الكتف", recoveryPercent = 82)
        assertNotNull(reply)
        assertTrue(reply!!.second.isSwapCard)
    }

    @Test
    fun workout_history_and_chat_serialization_roundtrip_is_lossless() {
        val logs = listOf(
            WorkoutLogEntry(
                id = "log_1",
                workoutId = "planche",
                title = BiText("Planche Foundations", "أساسيات البلانش"),
                kcal = 340,
                setsCompleted = 12,
                completedAtMillis = 1730000000000L
            )
        )
        val encodedLogs = PreferencesRepository.encodeWorkoutHistory(logs)
        val decodedLogs = PreferencesRepository.decodeWorkoutHistory(encodedLogs)
        assertEquals(logs, decodedLogs)

        val chat = listOf(
            ChatMessage(id = "u_1", isUser = true, text = BiText("Check squat", "افحص القرفصاء")),
            ChatMessage(id = "b_1", isUser = false, isSwapCard = true)
        )
        val encodedChat = PreferencesRepository.encodeChatHistory(chat)
        val decodedChat = PreferencesRepository.decodeChatHistory(encodedChat)
        assertEquals(chat, decodedChat)
    }
}
